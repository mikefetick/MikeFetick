//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Final May 2013, Practical Programming Portion
// Called by main
// Calls to get user input: a string, an integer, a double.
//
// 1. Create arrays to hold the names of 10 students, 
//    the student number for those ten students and the
//    the GPA for each student
//
//*************************************************************

import java.util.Scanner;
import java.util.InputMismatchException;

public class makeStudentArrays
{
    //Makes student arrays
    public static String iteratively()
    {
		String strLastName = "";
		int intNumber = 0;
		double dblGPA = 0;
		
		String[] studentLastNames = new String[10];
		   int[] studentNumbers = new int[10];
		double[] studentGPAs = new double[10];
		
		Scanner console = new Scanner(System.in);

		try{
		// Prompt the user to enter student's last name.
		System.out.print("Please enter the student's last name: ");
		strLastName = console.next();

		// Prompt the user to enter student's number.
		System.out.print("Please enter the student's number: ");
		intNumber = console.nextInt();

		// Prompt the user to enter student's GPA.
		System.out.print("Please enter the student's GPA: ");
		dblGPA = console.nextDouble();
		
		System.out.println(strLastName);
		System.out.println(intNumber);
		System.out.println(dblGPA);

		}catch(InputMismatchException ime){
			System.out.println("Invalid input, that is not a number.");
		}

	return strLastName;
    }
}