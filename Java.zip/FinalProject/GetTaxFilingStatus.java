//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Project 5, IV. Flag controlled while loop
// (2 points)
// This subsidiary module uses a while loop, controlled by a 
// Boolean flag. It prompts the user for input of either an 
// ‘M’,‘H’,‘S’ or ‘E’ and echoes a message stating the employee's 
// filing status, i.e. “Married” for ‘M’, “Single” for ‘S’, 
// “Head of Household” for ‘H’ and “Exempt” for ‘E’. 
// If any other character is entered then it changes the value 
// in the Boolean to terminate the execution of the program. 
//*************************************************************

import javax.swing.JOptionPane;

public class GetTaxFilingStatus
{
    //prompts for a name and calls MyAlphabetTester 
    //to validate the string has only letters
    public static String toTypeIn(String inputString)
    {
		String taxStatusString = " ";
		
		while((inputString.equals("M")) || (inputString.equals("H"))
		   || (inputString.equals("S")) || (inputString.equals("E")))
		{
	        inputString = JOptionPane.showInputDialog(null,
				"Enter a filing status, \n"
			  + "either \"M\", \"H\", \"S\", or \"E\": ",
				"IV. Flag controlled while loop",
				JOptionPane.QUESTION_MESSAGE);

			if ((inputString.equals("M")) || (inputString.equals("H"))
			|| (inputString.equals("S")) || (inputString.equals("E")))
			{
				int taxStatus = inputString.charAt(0);
				switch (taxStatus){
					case 'M': {taxStatusString = "Married";
						break;}
					case 'H': {taxStatusString = "Head Of Household";
						break;}
					case 'S': {taxStatusString = "Single";
						break;}
					case 'E': {taxStatusString = "Exempt";
						break;}
				}
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\" for \""
				  + taxStatusString + "\".",
					"IV. Flag controlled while loop",
					JOptionPane.INFORMATION_MESSAGE);
			} //end if "M","H","S",",or "E"
		} // end while
		return inputString;
    } // end method
}