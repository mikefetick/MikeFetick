//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Project 5, II. Using a counted loop
// Used when the actual parameter "some" is passed for selection
// (2 points)
//
// Program: Project 5, III. EOF Controlled While loop
// Used when the actual parameter "all" is passed for selection
// (2 points)
// This subsidiary module receives the filename as a parameter
// and performs file I/O operations to open and read records
// iteratively with the user, from the data file; then closes
// the data file.
//*************************************************************

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;

public class ReadFile
{
    //Reads a file iteratively, for each record
    public static String iteratively(String selection, String fileName)
    {
		FileReader reader = null;
		BufferedReader buffer = null;
		int i = 0,
		    c = 0;
		String userStrInput = " ",
		        titleString = " ";
		String[] employeeRecord = new String[8];

		try{
			titleString = "Input - File Operations";
			reader = new FileReader(fileName);
			buffer = new BufferedReader(reader);
			String line = buffer.readLine();
			employeeRecord = line.split(" ", 8);

			if (selection == "some"){
				//Prompt//Parse for number of records
				titleString = "II. Using a counted loop";
				userStrInput = JOptionPane.showInputDialog(null,
					"How many records (5)? ",
					titleString, JOptionPane.QUESTION_MESSAGE);
				int counter = Integer.parseInt(userStrInput);
				for(i = 1; i <= counter; i++)
				{
					if(line != null){
						System.out.println(employeeRecord[0]);
						System.out.println(line);
						//The place to code for an object to split
						//the line into non-whitespace strings
						JOptionPane.showMessageDialog(null,
						"You read: \n\n"
					  + "Emp     First      Last       "
					  + "Filiing    Exempt   Class"
					  + "Hrs    Pay Rate   Salary   Pay \n"
					  + "Num    Name    Name    Status \n\n"
							+ employeeRecord[0] + "\n",
//							+ line + "\n",
						    "II. Using a counted loop",
							JOptionPane.INFORMATION_MESSAGE);
						String nextline = buffer.readLine();
						line = nextline;
						employeeRecord = line.split(" ", 5);
						c++;
					}else{
						JOptionPane.showMessageDialog(null,
						"There were only "+ c +" records to read,\n"
						+ "not "+ counter +", as requested.");
						break;
					}
				}
			}if (selection == "all"){
				titleString = "III. EOF Controlled While loop";
				JOptionPane.showMessageDialog(null,
				"Press OK to read all the records.",
			    titleString, JOptionPane.INFORMATION_MESSAGE);
				while(line != null)
				{
					System.out.println(line);
					JOptionPane.showMessageDialog(null,
						"You read: \n\n"
					  + "Emp     First      Last       "
					  + "Filiing    Exempt   Class"
					  + "Hrs    Pay Rate   Salary   Pay \n"
					  + "Num    Name    Name    Status \n\n"
							+ line + "\n",
					    "III. EOF Controlled While loop",
						JOptionPane.INFORMATION_MESSAGE);
					String nextline = buffer.readLine();
					line = nextline;
				}
			}if(buffer != null){
				buffer.close();
				reader.close();
			}
		}catch(IOException ioe){
		    JOptionPane.showMessageDialog(null, ioe.getMessage(),
			titleString, JOptionPane.ERROR_MESSAGE);
		}catch(NumberFormatException nfe){
//			GetFilenameOrQuit promptUser = new GetFilenameOrQuit();
//			String aFilename = promptUser.toTypeIn("filename");
		    JOptionPane.showMessageDialog(null,
			"\"" + userStrInput + "\" is not a number",
			titleString, JOptionPane.ERROR_MESSAGE);
		}finally{
			if(buffer != null){
//				if(buffer == open){
//					buffer.close();
//					reader.close();
//				}
			}
		}
	return fileName;
	}
}
