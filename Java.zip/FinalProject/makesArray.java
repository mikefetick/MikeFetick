//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Final May 2013, Practical Programming Portion
// Called by main
// Calls to get user input: a string, an integer, a double.
//
// 1. Create arrays to hold the names of 10 students, 
//    the student number for those ten students and the
//    the GPA for each student
//
//*************************************************************

import java.util.InputMismatchException;

public class makesArray implements StudentData
{
    //Makes student arrays
    public static void iteratively()
    {
		String[] studentLastNames = new String[STUDENTS_ARRAY_LENGTH];
		   int[] studentNumbers = new int[STUDENTS_ARRAY_LENGTH];
		double[] studentGPAs = new double[STUDENTS_ARRAY_LENGTH];
		
		try{
 		for(int i = 0; i < STUDENTS_ARRAY_LENGTH; i++)
		{
			// 2a. Accept user input of 10 student last names
			GetInput studentLastName = new GetInput();
			studentLastNames[i] = studentLastName.toTypeIn("names");
		
			// 2b. Accept user input of 10 student numbers
			GetInput studentNumber = new GetInput();
			studentNumbers[i] = studentNumber.toTypeIn(0);
		
			// 2c. Accept user input of 10 student GPAs
			GetInput studentGPA = new GetInput();
			studentGPAs[i] = studentGPA.toTypeIn(0.0);
		}
		// 5. Report the data
 		for(int i = 0; i < STUDENTS_ARRAY_LENGTH; i++)
		{
			System.out.println(studentLastNames[i]);
			System.out.println(studentNumbers[i]);
			System.out.println(studentGPAs[i]);
		}
		}catch(InputMismatchException ime){
			System.out.println("Invalid input, that is not a number.");
		}
    }
}