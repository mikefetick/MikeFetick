//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Project 5, V. Forever loop
// (2 points)
// This subsidiary module uses a forever, while loop, controlled
// by a Boolean flag, with the same processing as in part IV. 
// It prompts the user for input of either an ‘M’,‘H’,‘S’ or ‘E’. 
// It echoes a message stating the employees filing status, i.e. 
// “Married” for ‘M’, “Single” for ‘S’, “Head of Household”
// for ‘H’ and “Exempt” for ‘E’. 
// The code in block comments, are the two other loop types:
// the for and do loop… The user can quit by entering the 
// particular value "Q" and “break” the loop. Invalid input 
// results an error message and opportunity to try again.
//*************************************************************

import javax.swing.JOptionPane;

public class GetTaxFilingStatusForever
{
    //prompts for a name and calls MyAlphabetTester 
    //to validate the string has only letters
    public static String toTypeIn(String inputString)
    {
		String taxStatusString = " ";
		
		while((inputString.equals("M")) || (inputString.equals("H"))
		    || (inputString.equals("S")) || (inputString.equals("E")))
		{
	        inputString = JOptionPane.showInputDialog(null,
				"Enter a filing status, \n"
			  + "either \"M\", \"H\", \"S\", or \"E\""
			  + "or a \"Q\"to Quit: ",
				"V. Forever loop",
				JOptionPane.QUESTION_MESSAGE);

			if ((inputString.equals("M")) || (inputString.equals("H"))
			|| (inputString.equals("S")) || (inputString.equals("E")))
			{
				int taxStatus = inputString.charAt(0);
				switch (taxStatus){
					case 'M': {taxStatusString = "Married";
						break;}
					case 'H': {taxStatusString = "Head Of Household";
						break;}
					case 'S': {taxStatusString = "Single";
						break;}
					case 'E': {taxStatusString = "Exempt";
						break;}
				}
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\" for \""
				  + taxStatusString + "\".",
					"V. Forever loop",
					JOptionPane.INFORMATION_MESSAGE);
			}else{
				if (inputString.equals("Q")){
					break;
				}else{
					JOptionPane.showMessageDialog(null,
						"You entered \"" + inputString + "\"\n"
					  + "That is not valid! Try again.",
						"V. Forever loop",
						JOptionPane.ERROR_MESSAGE);
					inputString = "S";
				} //else not "Q"
			} //end if "M","H","S",","E",or "Q"
		} // end while
		return inputString;
    } // end method
}