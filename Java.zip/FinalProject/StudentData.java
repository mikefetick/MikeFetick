public interface StudentData
{
		static final int STUDENTS_ARRAY_LENGTH = 10;
}
