//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: A module that prompts for a name and calls
// MyAlphabetTester to validate the string has only letters
//*************************************************************

import javax.swing.JOptionPane;
import java.lang.*;

public class Project5
{
    public static void main (String[] args)
    {
		GetInput promptUser = new GetInput();

		String aName = promptUser.toTypeIn("letters");
	}
}