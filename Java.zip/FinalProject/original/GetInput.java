//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: A module that gets imput with various methods.
// MyAlphabetTester to validate the string has only letters
//*************************************************************

import javax.swing.JOptionPane;

public class GetInput
{
    //prompts for a name and calls MyAlphabetTester 
    //to validate the string has only letters
    public static String toTypeIn(String inputString)
    {
	
		while (!((inputString.equals("Q")) || (inputString.equals("q"))))
		{
	        inputString = JOptionPane.showInputDialog
	           ("Enter a name or a \"q\" to quit: ");

	   		if ((inputString.equals("Q")) || (inputString.equals("q")))
				return inputString;

//			if(inputString != null &&
			if(MyAlphabetTester.isStringOkay(inputString))
			{
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\"");
				return inputString;
			}else
	            JOptionPane.showMessageDialog(null, "\"" + inputString
	            	+ "\" ?\nThat input is not valid");
		}
	return inputString;
    }
}