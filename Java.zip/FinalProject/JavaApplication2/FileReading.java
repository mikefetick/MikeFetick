import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileReading {

    private static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        FileReader reader = null; 
        BufferedReader buffer = null;
        
        try{
            reader = new FileReader(input.nextLine());
            buffer = new BufferedReader(reader);

            String line = buffer.readLine();
            while(line != null){
                System.out.println(line);

                line = buffer.readLine();
            }
        }catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }finally{
            if(buffer != null){
                try{
                buffer.close();
                }catch(IOException ioe){
                    System.out.println(ioe.getMessage());
                }
            }
            if(reader != null){
                try{
                reader.close();
                }catch(IOException ioe){
                    System.out.println(ioe.getMessage());
                }
            }
        }
    }
}
