//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Project 5, II. Using a counted loop
// Used when the actual parameter "some" is passed for selection
// (2 points)
//
// Program: Project 5, III. EOF Controlled While loop
// Used when the actual parameter "all" is passed for selection
// (2 points)
// This subsidiary module receives the filename as a parameter
// and performs file I/O operations to open and read records
// iteratively with the user, from the data file; then closes
// the data file.
//*************************************************************

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;

public class ReadFile
{
    //Reads a file iteratively, for each record
    public static String iteratively(String selection, String fileName)
    {
	FileReader reader = null;
	BufferedReader buffer = null;
	int i = 0,
            f = 0,
            c = 0;
	String userStrInput = "",
                tableHeader = "",
             employeeRecord = "",
                titleString = "";
	String[] strField = new String[10];

	try
        {
	titleString = "Input - File Operations";
	reader = new FileReader(fileName);
	buffer = new BufferedReader(reader);
	String line = buffer.readLine();
        System.out.println(line);
	strField = line.split("\t");
        for(f = 0; f <= 9; f++){
            tableHeader = tableHeader + strField[f] + "   ";
        }
        line = buffer.readLine();
	if (selection == "some"){
	    //Prompt//Parse for number of records
	    titleString = "II. Using a counted loop";
	    userStrInput = JOptionPane.showInputDialog(null,
	        "How many records (5)? ",
	        titleString, JOptionPane.QUESTION_MESSAGE);
	    int counter = Integer.parseInt(userStrInput);
	    for(i = 1; i <= counter; i++){
                if(line != null){
		    strField = line.split("\t");
                    for(f = 0; f <= 9; f++){
                      employeeRecord = employeeRecord 
                                     + strField[f] + "       ";
                    } //for
		    System.out.println(line);
		    JOptionPane.showMessageDialog(null,
		        "You read: \n\n" + tableHeader + "\n\n"
		      + employeeRecord + "\n",
                        "II. Using a counted loop",
                        JOptionPane.INFORMATION_MESSAGE);
		    line = buffer.readLine();
		    employeeRecord = "";
                    c++;
	        }else{ //if(line != null)
		    JOptionPane.showMessageDialog(null,
		        "There were only "+ c +" records to read,\n"
		      + "not "+ counter +", as requested.");
		    break;
		} // else
	    } //for(i = 1; i <= counter; i++)
	}if (selection == "all") //if (selection == "some")
         { 
	    titleString = "III. EOF Controlled While loop";
	    JOptionPane.showMessageDialog(null,
		"Press OK to read all the records.",
	        titleString, JOptionPane.INFORMATION_MESSAGE);
	    while(line != null){
		strField = line.split("\t");
                for(f = 0; f <= 9; f++){
                    employeeRecord = employeeRecord
                                   + strField[f] + "       ";
                } //for
		System.out.println(line);
		JOptionPane.showMessageDialog(null,
		    "You read: \n\n" + tableHeader + "\n\n"
		  + employeeRecord + "\n",
		    "III. EOF Controlled While loop",
		    JOptionPane.INFORMATION_MESSAGE);
		line = buffer.readLine();
		employeeRecord = "";
	    } //while(line != null)
	 } //if (selection == "all")
 	}catch(IOException ioe){ //try
	    JOptionPane.showMessageDialog(null, ioe.getMessage(),
		titleString, JOptionPane.ERROR_MESSAGE);
	}catch(NumberFormatException nfe){
//	//GetFilenameOrQuit promptUser = new GetFilenameOrQuit();
//	//String aFilename = promptUser.toTypeIn("filename");
	    JOptionPane.showMessageDialog(null,
		"\"" + userStrInput + "\" is not a number",
		titleString, JOptionPane.ERROR_MESSAGE);
        }finally{
            if(buffer != null){
                try{
                buffer.close();
                }catch(IOException ioe){
                    System.out.println(ioe.getMessage());
                }
            }
            if(reader != null){
                try{
                reader.close();
                }catch(IOException ioe){
                    System.out.println(ioe.getMessage());
                }
            }
        } //finally
        return fileName;
    } //public static String iteratively
} //public class ReadFile
