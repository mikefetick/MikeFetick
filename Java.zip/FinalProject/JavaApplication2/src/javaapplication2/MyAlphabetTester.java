//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: A subsidiary module that checks the characters of a
// string to validate it has only letters and returns a Boolean.
//*************************************************************

public class MyAlphabetTester
{
	public static boolean isStringOkay (String test)
	{
		boolean areLetters = false;

		int strCount = test.length();

		for(int i = 0; i < strCount; i++)
		{
			areLetters = ( (Character.isLowerCase(test.charAt(i))) ||
				(Character.isUpperCase(test.charAt(i))) );

			if(areLetters == false)
				return false;
		}
	return true;
	}
}


