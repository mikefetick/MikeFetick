//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Iteration – Project 5
// This main module performs the following tasks and calls the 
// corresponding subsidiary modules with a return value:
// I. Using a sentinel controlled loop (2 points)
//   Class: GetInputOrQuit
//   Object: promptUser
//   Method: toTypeIn
//   Returns: aName
// II. Using a counted loop (2 points)

//   Class: ReadFile
//   Object: getSomeRecords
//   Method: iteratively(some)
//   Returns: SomeEmployeeData
// III. EOF Controlled While loop ( 2 points)
//   Class: ReadFile
//   Object: getAllRecords
//   Method: iteratively(all)
//   Returns: AllEmployeeData
// IV. Flag controlled while loop (2 points)
//   Class: GetTaxFilingStatus
//   Object: promptChoice
//   Method: toTypeIn
//   Returns: filingStatus
// V. Forever loop (2 points)
//   Class: GetTaxFilingStatusForever
//   Object: foreverChoosing
//   Method: toTypeIn
//   Returns: filingStatusForever
//*************************************************************

// Iteration – Project 5
public class Project5
{
    public static void main (String[] args)
    {
		// I. Using a sentinel controlled loop (2 points)
		GetInputOrQuit promptUser = new GetInputOrQuit();
		String aName = promptUser.toTypeIn("letters");
		
		// II. Using a counted loop (2 points)
		ReadFile getSomeRecords = new ReadFile();
		String SomeEmployeeData = 
			getSomeRecords.iteratively("some","payrollData.txt");
		
		// III. EOF Controlled While loop ( 2 points)
		ReadFile getAllRecords = new ReadFile();
		String AllEmployeeData = 
			getAllRecords.iteratively("all","payrollData.txt");

		// IV. Flag controlled while loop (2 points)
		GetTaxFilingStatus promptChoice = new GetTaxFilingStatus();
		String filingStatus = promptChoice.toTypeIn("S");
		
		// V. Forever loop (2 points)
		GetTaxFilingStatusForever foreverChoosing = 
			new GetTaxFilingStatusForever();
		String filingStatusForever = foreverChoosing.toTypeIn("S");
	}
}
/* OUTPUT
EmpNo	FName	LName	TaxStat	Exem	Class	Hrs	PRate	Sal	Pay
1001	Alex	Aware	   S	  11	   H	40   	15.35	0   	1228 
1002	Ben	Before	   S	  10	   H	38   	15   	0   	570  
1003	Chad	Cause	   S	   9	   H	26.45	20   	0   	1058 
1004	Dan	Dress	   S	   8	   H	20   	39.15	0   	2349 
1005	Ely	Effort	   S	   7	   H	37.15	20   	0   	1486 
EmpNo	FName	LName	TaxStat	Exem	Class	Hrs	PRate	Sal	Pay
1001	Alex	Aware	   S	  11	   H	40   	15.35	0   	1228 
1002	Ben	Before	   S	  10	   H	38   	15   	0   	570  
1003	Chad	Cause	   S	   9	   H	26.45	20   	0   	1058 
1004	Dan	Dress	   S	   8	   H	20   	39.15	0   	2349 
1005	Ely	Effort	   S	   7	   H	37.15	20   	0   	1486 
1006	Frank	Family	   S	   6	   H	55.35	20   	0   	5535 
1007	George	Guest	   S	   5	   H	53.3 	20   	0   	1066 
1008	Hank	Honor	   S	   4	   S	0    	0    	1430	14300
1009	Isaac	Issue	   S	   3	   S	0    	0    	1389	13890
1010	John	Joke	   S	   2	   S	0    	0   	1777	15993
*/