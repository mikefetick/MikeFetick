//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Project 5, I. Using a sentinel controlled loop
// (2 points)
// This subsidiary module prompts the user to enter a name and 
// echoes that name to the screen. The program will continue 
// to do this until the user enters a sentinel value.
//*************************************************************

import javax.swing.JOptionPane;

public class GetInputOrQuit
{
    //prompts for a name and calls MyAlphabetTester 
    //to validate the string has only letters
    public static String toTypeIn(String inputString)
    {
	
		while (!((inputString.equals("Q")) || (inputString.equals("q"))))
		{
	        inputString = JOptionPane.showInputDialog(null,
				"Enter a name or a \"q\" to quit: ",
				"I. Using a sentinel controlled loop",
					JOptionPane.QUESTION_MESSAGE);

	   		if ((inputString.equals("Q")) || (inputString.equals("q")))
				return inputString;

			if(MyAlphabetTester.isStringOkay(inputString))
			{
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\"",
					"I. Using a sentinel controlled loop",
					JOptionPane.INFORMATION_MESSAGE);
				return inputString;
			}else
	            JOptionPane.showMessageDialog(null, "\"" + inputString
	            	+ "\" ?\nThat input is not valid");
		}
	return inputString;
    }
}