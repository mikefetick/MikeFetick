//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: A module that gets imput with various methods.
// MyAlphabetTester to validate the string has only letters
//*************************************************************

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;

public class ReadFile
{
    //Reads a file iteratively, for each record
    public static String iteratively(String fileName)
    {
		FileReader reader = null;
		BufferedReader buffer = null;
		int counter = 0, 
		          c = counter;
		String userStrInput = "";
		
		try{
			reader = new FileReader(fileName);
			buffer = new BufferedReader(reader);
			String line = buffer.readLine();
			//Prompt//Parse for number of records
			userStrInput = JOptionPane.showInputDialog(null,
				"How many records (5)? ",JOptionPane.QUESTION_MESSAGE);
			counter = Integer.parseInteger(userStrInput);
		
			while(line != null)
			{
				for(c, c <= counter, c++)
				{
				System.out.println(line);
				JOptionPane.showMessageDialog(null,
					"You read \"" + line + "\"");
				String nextline = buffer.readLine();
				line = nextline;
				}
			}
			if(buffer != null){
				buffer.close();
				reader.close();
			}
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		    JOptionPane.showMessageDialog(null, ioe.getMessage(),
			"Input Error - DATA FILE", JOptionPane.ERROR_MESSAGE);
		}finally{
			if(buffer != null){
				if(buffer == open){
//					buffer.close();
//					reader.close();
				}
			}
		}
	return fileName;
	}
}
