//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Final May 2013, Practical Programming Portion
// Called by makeStudentArrays
// This subsidiary module has three constructors to prompt 
// the user to enter data: a string, an integer, a double.
//
// 2. Accept from the user the input of the 10 names,
//    last name only, the numeric student number,
//    (whole number), and the student's GPA.
//
//*************************************************************
import java.util.InputMismatchException;
import java.util.Scanner;

public class GetInput
{
   //Prompts for a student's last name, returns strLastName
    public static String toTypeIn(String strLastName)
    {
		Scanner console = new Scanner(System.in);
		try{
		boolean goodInput = false;
		while (!goodInput){
			// Prompt the user to enter student's last name.
			System.out.print("Please enter the student's last name: ");
			strLastName = console.next();
			goodInput = true;
			System.out.println(strLastName);
			}
		}catch(InputMismatchException ime){
			System.out.println("Invalid input, that is not a number.\n");
		}
		return strLastName;
    }
    //Prompts for a student's number, returns intNumber
    public static int toTypeIn(int intNumber)
    {
		Scanner console = new Scanner(System.in);
		try{
		boolean goodInput = false;
		while (!goodInput){
			// Prompt the user to enter student's number.
			System.out.print("Please enter the student's number: ");
			intNumber = console.nextInt();
			goodInput = true;
			System.out.println(intNumber);
			}
		}catch(InputMismatchException ime){
			System.out.println("Invalid input, that is not a number.\n");
		}
		return intNumber;
    }
    //Prompts for a student's GPA, returns dblGPA
    public static double toTypeIn(double dblGPA)
    {
		Scanner console = new Scanner(System.in);
		try{
		boolean goodInput = false;
		while (!goodInput){
			// Prompt the user to enter student's GPA.
			System.out.print("Please enter the student's GPA: ");
			dblGPA = console.nextDouble();
			goodInput = true;
			System.out.println(dblGPA);
			}
		}catch(InputMismatchException ime){
			System.out.println("Invalid input, that is not a number.\n");
		}
		return dblGPA;
    }
}