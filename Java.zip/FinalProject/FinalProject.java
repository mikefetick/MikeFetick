//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Final May 2013, Practical Programming Portion
//
// This main module performs the following tasks and calls the 
// corresponding subsidiary modules for a return value:
// 1. Create arrays to hold the names of 10 students, 
//    the student number for those ten students and the
//    the GPA for each student
// 2. Accept from the user the input of the 10 names,
//    last name only, the numeric student number,
//    (whole number), and the student's GPA.
//*************************************************************

// Final May 2013

public class FinalProject
{
    public static void main (String[] args)
    {
		// 1. Create parallel arrays to hold data of 10 students
		makesArray.iteratively();
	}
}
/* OUTPUT
S:\...MyProjectCode )java FinalProject
Please enter the student's last name: nam1
nam1
Please enter the student's number: 1
1
Please enter the student's GPA: 1.1
1.1
Please enter the student's last name: nam2
nam2
Please enter the student's number: 2
2
Please enter the student's GPA: 1.2
1.2
Please enter the student's last name: nam3
nam3
Please enter the student's number:
*/