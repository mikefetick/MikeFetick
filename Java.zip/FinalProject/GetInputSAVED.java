//*************************************************************
// Author: Mike Fetick, Student No. 84270, COM107 COLEMAN U.
//
// Program: Project 5, I. Using a sentinel controlled loop
// (2 points)
// This subsidiary module prompts the user to enter a name and 
// echoes that name to the screen. The program will continue 
// to do this until the user enters a sentinel value.

// 2. Accept from the user the input of the 10 names,
//    last name only, the numeric student number,
//    (whole number), and the student's GPA.

//*************************************************************

import javax.swing.JOptionPane;

public class GetInput
{
    //Prompts for a student's last name, 
	//calls MyAlphabetTester to validate,
    //returns strLastName
    public static String toTypeIn(String inputString)
    {
		int i = 0;
		while (!((inputString.equals("Q")) || (inputString.equals("q"))))
		{
	        i++;
			inputString = JOptionPane.showInputDialog(null,
				"Enter student("+i+")'s last name or a \"q\" to quit: ",
				"Please enter 10 students' last names...",
					JOptionPane.QUESTION_MESSAGE);

	   		if ((inputString.equals("Q")) || (inputString.equals("q")))
				return inputString;

			if(MyAlphabetTester.isStringOkay(inputString))
			{
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\"",
					"Please enter 10 students' last names...",
					JOptionPane.INFORMATION_MESSAGE);
				System.out.println(inputString);
				return inputString;
			}else
	            JOptionPane.showMessageDialog(null, "\"" + inputString
	            	+ "\" ?\nThat input is not valid");
		}
	System.out.println(strLastName);
	return strLastName;
    }
    //Prompts for a student's number, 
	//calls MyNumberTester to validate,
    //returns intNumber
    public static int toTypeIn(int intNumber)
    {
		while (!((inputString.equals("Q")) || (inputString.equals("q"))))
		{
	        inputString = JOptionPane.showInputDialog(null,
				"Enter student("+i+")'s number or a \"q\" to quit: ",
				"Please enter 10 students' numbers...",
					JOptionPane.QUESTION_MESSAGE);

	   		if ((inputString.equals("Q")) || (inputString.equals("q")))
				return inputString;

			if(MyAlphabetTester.isStringOkay(inputString))
			{
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\"",
					"Please enter 10 students' numbers...",
					JOptionPane.INFORMATION_MESSAGE);
				return inputString;
			}else
	            JOptionPane.showMessageDialog(null, "\"" + inputString
	            	+ "\" ?\nThat input is not valid");
		}
	return intNumber;
    }
    //Prompts for a student's GPA, 
	//calls MyNumberTester to validate,
    //returns dblGPA
    public static String toTypeIn(double dblGPA)
    {
		while (!((inputString.equals("Q")) || (inputString.equals("q"))))
		{
	        inputString = JOptionPane.showInputDialog(null,
				"Enter student("+i+")'s GPA or a \"q\" to quit: ",
				"Please enter 10 students' GPAs...",
					JOptionPane.QUESTION_MESSAGE);

	   		if ((inputString.equals("Q")) || (inputString.equals("q")))
				return inputString;

			if(MyAlphabetTester.isStringOkay(inputString))
			{
				JOptionPane.showMessageDialog(null,
					"You entered \"" + inputString + "\"",
					"lease enter 10 students' GPAs...",
					JOptionPane.INFORMATION_MESSAGE);
				return inputString;
			}else
	            JOptionPane.showMessageDialog(null, "\"" + inputString
	            	+ "\" ?\nThat input is not valid");
		}
	return dblGPA;
    }
}