/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Project 3 - GUI Customer Inventory (10 points)
 */
package storeinventory;

/**
 *
 * @author admin
 */
public interface Items {
    
    public void Item();

    public void Item(String strItemID, 
                String strItemName, 
                int intPiecesInStore, 
                double dblManufPrice, 
                double dblSellingPrice);

    public String getStrItemID();

    public void setStrItemID(String strItemID);

    public String getStrItemName();

    public void setStrItemName(String strItemName);

    public int getIntPiecesInStore();

    public void setIntPiecesInStore(int intPiecesInStore);

    public double getDblManufPrice();

    public void setDblManufPrice(double dblManufPrice);

    public double getDblSellingPrice();

    public void setDblSellingPrice(double dblSellingPrice);
                        
    // 6) Override the toString() method
    @Override
    public String toString();

}