/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 */
package storeinventory;

/**
 * A subclass of superclass Customer
 * @author Michael Fetick, 84270
 */
public class CreditCustomer extends Customer {
    
    private String paymentType;
    
    public CreditCustomer(int idNumber, 
                        String name, 
                        double creditLimit, 
                        String creditPayment) {
        super(idNumber, 
              name, 
              creditLimit);
        this.setPaymentType(creditPayment);
    }
    
    private String getPaymentType() {
        return this.paymentType;
    }
    
    private void setPaymentType(String creditPayment) {
        this.paymentType = creditPayment;
    }

    public void addCreditSurcharge(double subTotal, double creditSurcharge) {
//        subTotal = subTotal + creditSurcharge;
//        return subTotal;
    }
}