/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Project 3 - GUI Customer Inventory (10 points)
 */
package storeinventory;

/**
 * 8)Reuse code from Week2\SinglyLinkedList
 * This class has accessors and mutators to the objects of Customer
 * @author Michael Fetick, 84270
 */
public class Customer {
    private Customer next;
    private int idNumber;
    private String name;
    private String custAddr;
    private String custType;
    private double creditLimit;

    public Customer(int idNumber, String name, double creditLimit) {
        this.idNumber = idNumber;
        this.name = name;
        this.creditLimit = creditLimit;
    }    
    public Customer(int idNumber, String name, String custAddr, String custType) {
        this.idNumber = idNumber;
        this.name = name;
        this.custAddr = custAddr;
        this.custType = custType;
    }    

    public Customer getNext() {
        return next;
    }
    public int getIdNumber() {
        return idNumber;
    }
    public String getName() {
        return name;
    }
    public String getCustAddr() {
        return custAddr;
    }
    public String getCustType() {
        return custType;
    }
    public double getCreditLimit() {
        return creditLimit;
    }
    public void setNext(Customer next) {
        this.next = next;
    }
    @Override
    public String toString() {
        return this.name;
    }
    public String iDtoString() {
        String strIdNumber = idNumber + " " + name;
        return strIdNumber;
    }
}