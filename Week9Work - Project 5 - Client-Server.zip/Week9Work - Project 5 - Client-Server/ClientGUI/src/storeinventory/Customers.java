/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Project 3 - GUI Customer Inventory (10 points)
 */
package storeinventory;

/**
 *
 * @author admin
 */
public interface Customers<T> {
    
    public void Customer(int idNumber, String name, double creditLimit);

    public Customer getNext();
    
    public int getIdNumber();
    
    public String getName();
    
    public Double getCreditLimit();
    
    public void setNext(Customer next);
    
    @Override
    public String toString();
    
}