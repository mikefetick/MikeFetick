/* COM285, Michael Fetick, 84270
 * Project 1 - Creating Classes - Inventory (10 points)
 * Exercise 2 - Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Exercise 5 - Read a file to an ArrayList and Sort it(2 points)
 *              This class has the Main() method
 *   Step 1. Create method DataFileOperations.readProductFile()
 *           to read data from "Product.csv"
 *   Step 2. Create a constructor in the class Item, for:
 *           Item(String ItemID, 
 *                String ItemName, 
 *                double SellingPrice)
 *   Step 3. In this class where the Main() method starts...
 *           Replace: ArrayList<Item> alMain = initializeItem()
 *              with: ArrayList<Item> alMain = readProductFile()
 *   Step 4. Sort ArrayList with Collections.sort(alMain). First, make
 *           "public class Item implements Comparable<Item>" then
 *           override String.compareTo with "strThisItem.compareTo(strE)"
 * Project 3 - GUI Customer Inventory (10 points)
 */
package storeinventory;

import java.util.*;
import static storeinventory.Inventory.itemReport;

/**
 * 1)Create the project and generate this class with the main method
 * @author Michael Fetick, 84270
 */

public class StoreInventory extends Inventory {

    /**
     * The main method of the program
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // While loop, menu display/input, call methods of arraylist

        //Step 3. Replaced and deleted: 
        // ArrayList<Item> alMain = initializeItem();
        ArrayList<Item> alMain = readProductFile();

        Collections.sort(alMain);
        
        Scanner input = new Scanner(System.in);
        
        while(true){ // while exit has not been selected
            displayMenu();
            String s = input.next(); // Accept the keyboard entry
            System.out.println();    // Move down to a fresh line
            int n = Integer.parseInt(s); 

            //Welcome to the Java Hardware Store
            switch(n){
                //1. Check whether an item is in the store
                case 1: itemCheckDialogue(alMain);  //Inventory
                          continue;
                //2. Sell an item
                case 2: sellAnItem(alMain);         //Inventory
                          continue;
                //3. Print the report
                case 3: itemReport(alMain);         //Inventory
                          continue;
                //4. Exit
                case 4: 
                    System.out.println(
                               "\nThank you for using this program.\n");
                    System.exit(0);
                default: 
                    System.out.printf(
                               "\nPlease select 1, 2, 3, ot 4.\n\n");
            } // switch        
        } // while
    } // main
} // StoreInventory