/* COM285, Michael Fetick, 84270
 * Exercise 2: Read a file to a Linked List (2 Points)
 * Project 2 - Inheritance (10 points)
 * Project 3 - GUI Customer Inventory (10 points)
 */
package storeinventory;

/**
 * 8)Reuse code from Week2\SinglyLinkedList.
 *   a)Copy all files: SinglyLinkedList.java, LinkedListOps.java, and Customer.java
 * This class performs LinkedListOps
 * @author Michael Fetick, 84270
 */
public class LinkedListOps {

    protected static int thisCustomerId = 0;
    protected static String thisCustomerName = "";
//  //For Project 3 GUI datafile: customer.csv            
    protected static String thisCustomerAddr = "";
    protected static String thisCustomerType = "";
//  //For Project 2 datafile: customer2.csv            
    protected static double thisCreditLimit = 0;
    protected static int counter = 0;

    public static Customer head = null;
    
    public static int size(){
        return counter;
    }
    
    public void list(){
        Customer p;
        p = head;
        System.out.println("Customer Database - - - - - - - - - - -"); 
        System.out.println("  ID  Name                 Credit Limit"); 
        while(p != null){
//            System.out.printf("%4d  %-20s %7.2f\n", 
            System.out.printf("%4d  %-20s %-20s %-20s\n", 
                    p.getIdNumber(), 
                    p.getName(),
//                  //For Project 3 GUI datafile: customer.csv            
                    p.getCustAddr(),
                    p.getCustType());
//                  //For Project 2 datafile: customer2.csv            
//                    p.getCreditLimit());
            p = p.getNext(); // advance through list
        }//end while(p != null){
    }//public void list(){

    /**
     *
     * @param customerId
     * @return
     */
    public static Customer findCustomerId(int customerId){
        Customer p;
        p = head;
        Customer thisNode = p;
        while(p != null){
            if (p.getIdNumber() == customerId) {
                thisNode = p;
                thisCustomerId = customerId;
                thisCustomerName = p.getName();
//              //For Project 3 GUI datafile: customer.csv            
                thisCustomerAddr = p.getCustAddr();
                thisCustomerType = p.getCustType();
//                  //For Project 2 datafile: customer2.csv            
//                thisCreditLimit = p.getCreditLimit();
            }
            p = p.getNext(); // advance through list
        }//end while(p != null){
        return thisNode;
    }//public static Customer findCustomerId(int customerId){

    public void insert(Customer newNode){
        if(head == null){
            head = newNode;
            return;
        }
        newNode.setNext(head);
        head = newNode;  
        counter++;
    }//public void insert(Customer newNode){

    public void insertInOrder(Customer newNode){    
        Customer p, q;
        // case 1: the list is empty
        if(head == null){
            head = newNode;
            return;
        }
        // case 2: the node at head is >= to the new node so insert new node in front
        if(head.getIdNumber() > newNode.getIdNumber()){
            newNode.setNext(head); // attach the list to the new node
            head = newNode;      // point head at the new node
            return;
        }
        // case 3: the node at head is less than the new node
        p = head;
        q = head;
        while(p.getIdNumber() < newNode.getIdNumber() ){
           q = p;               // q follows p
           p = p.getNext();     // advance p in list to next node
           if(p == null){       // if end of list break to append newNode
               break;
           }
        }//end while(p.getIdNumber() < newNode.getIdNumber() ){
        q.setNext(newNode);     // insert the newNode
        newNode.setNext(p);     // newNode point to the rest of the list or null
        counter++;

    }//public void insertInOrder(Customer newNode){
 }//public class LinkedListOps {