/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package requester;

import java.util.Iterator;


public class OrderEntryImpl extends OrderEntry {

        public Iterator iterator() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
