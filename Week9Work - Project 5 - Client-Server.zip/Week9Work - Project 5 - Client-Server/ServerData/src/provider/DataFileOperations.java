/* COM285, Michael Fetick, 84270
 * Project 5 - Server data: read data from file(s)
 */
package provider;

//import storeinventory.*;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

/**
 * 9)Reuse code from Project 3
 * @author Michael Fetick, 84270
 */
public class DataFileOperations {

    private static ArrayList<Item> alInventory;
    private static String message;
    private boolean dataSent = false;
    private ObjectOutputStream out;
    
    public void sendMessage(String msg, ObjectOutputStream out) {
        try {
//            System.out.println("test: " + msg);
                out.writeObject(msg);
                out.flush();
                System.out.println("server>" + msg);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public boolean sentInventoryFile(ObjectOutputStream out) throws NoSuchElementException {
        
        FileReader inventoryDataFile = null;
        BufferedReader inventoryData = null;
        try { 
            inventoryDataFile = new FileReader("Inventory.csv");
            inventoryData = new BufferedReader(inventoryDataFile);
        } catch (FileNotFoundException fnfe) {
            System.err.println("Inventory datafile:  " + fnfe.getMessage());
            System.exit(1);
        }
        Scanner scanner = new Scanner(inventoryData);
        scanner.useLocale(Locale.US);
        scanner.useDelimiter("[,\n]");  // Comma Separated Value csv file
	ArrayList<Item> alInventory = new ArrayList();
        int i = 0;
        sendMessage("Data start", out);
        while (scanner.hasNext()) { // while has next recond
            String productId = scanner.next();
            message = productId;
            sendMessage(message, out);
            String qtyOnHand = scanner.next();
            qtyOnHand = qtyOnHand.trim();
            message = qtyOnHand;
            sendMessage(message, out);
            int intQtyOnHand = Integer.parseInt(qtyOnHand); 
            Item thisItem2 = new Item(productId,
                                     intQtyOnHand);
            alInventory.add(thisItem2);
        }
        dataSent = true;
        sendMessage("Data end", out);
        try {
            //Close stream objects
            if (inventoryData != null){
                inventoryData.close();
            }
        } catch (IOException ioe) {
            System.err.println("Inventory datafile:  " + ioe.getMessage());
            System.exit(1);
        }
    return dataSent;
    }
}
