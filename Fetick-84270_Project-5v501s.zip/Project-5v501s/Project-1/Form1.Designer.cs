﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System.Collections;
using ArkhamBooks.Properties;
using System.Windows.Forms;

namespace ArkhamBooks
{
    partial class frmOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing); 
        }

        /// <summary>
        /// Date: 16 January 2014
        /// Edits to implement the Error Provider (EP) feature for handling entry errors in all textboxes:
        ///   1. Created a new label (EPL) for: txtFirstNameEPL,txtLastNameEPL, txtAddressEPL,
        ///      txtCityEPL, cboStateEPL, txtZipCodeEPL, txtEmailEPL, and txtQtyEPL
        ///   2. Generated/organized the field stubs for each of the EPs and EPLs
        ///   3. Created Error Providers (EP) and copied/customized snippets for each textbox
        ///   4. Create functions {*}_Validated to be called when grpCustomer loses focus
        ///   5. Create sub-functions Is{*}Valid to be called to verify data for each textbox
        ///   6. Had to make space for the label to appear on the right of the textbox.
        ///   
        /// ---
        /// Date: 17 January 2014
        /// Edits in design view (from defaults):
        ///   cboTitle-DropDownStyle(DropDown) - (DropDownList) restricts typing in the control
        ///   frmOrderForm-MaximizeBox(True)          - (False) restricts maximizing the window
        ///   frmOrderForm-FormBorderStyle(Sizable) - (Fixed3D) restricts resizing the window
        ///   txtAuthor, txtISBN, txtPrice, txtCost, 
        ///   txtSubtotal, txtShipping, txtTax, 
        ///   txtTotal -Enabled(True)                 - (False) restricts editing
        ///   txtQty-Text()                               - (1) create a default of one
        /// ---
        /// Date: 18 January 2014
        /// Edits to implement the Error Provider (EP) for an additional textbox - txtQty:
        ///   1. In BookData, had to add another property to Book: qty 
        /// Date: 1 February 2014
        ///   1. Copied Project 2 for Project 3
        ///   2. Edits to implement the Error Provider (EP) for Credit card information, i.e.
        ///      an additional textbox - txtCcName
        ///      an additional textbox - txtCcNumber
        ///      an additional combobox - cboCcExpM
        ///      an additional combobox - cboCcExpY
        ///      an additional textbox - txtCcCvc
        /// ---
        /// </summary>

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtFirstNameEPL = new System.Windows.Forms.Label();
            this.txtLastNameEPL = new System.Windows.Forms.Label();
            this.txtAddressEPL = new System.Windows.Forms.Label();
            this.txtCityEPL = new System.Windows.Forms.Label();
            this.cboStateEPL = new System.Windows.Forms.Label();
            this.txtZipCodeEPL = new System.Windows.Forms.Label();
            this.txtEmailEPL = new System.Windows.Forms.Label();
            this.txtQtyEPL = new System.Windows.Forms.Label();
            this.txtCcNumberEPL = new System.Windows.Forms.Label();
            this.grpCustomer = new System.Windows.Forms.GroupBox();
            this.lblAlertCutomer = new System.Windows.Forms.Label();
            this.cboCustomer = new System.Windows.Forms.ComboBox();
            this.btnCustomerAdd = new System.Windows.Forms.Button();
            this.btnCustomerSave = new System.Windows.Forms.Button();
            this.btnCustomerCancel = new System.Windows.Forms.Button();
            this.btnCustomerEdit = new System.Windows.Forms.Button();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.txtCcCvc = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblCcCvc = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.nudCcExpYYYY = new System.Windows.Forms.NumericUpDown();
            this.lblEmailOptional = new System.Windows.Forms.Label();
            this.nudCcExpMM = new System.Windows.Forms.NumericUpDown();
            this.lblExpires = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtCcNumber = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblCcNumber = new System.Windows.Forms.Label();
            this.cboState = new System.Windows.Forms.ComboBox();
            this.txtCcName = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.lblCcName = new System.Windows.Forms.Label();
            this.txtZipCode = new System.Windows.Forms.TextBox();
            this.lblCreditCard = new System.Windows.Forms.Label();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.cboCreditCard = new System.Windows.Forms.ComboBox();
            this.lblAlertOrderSummary = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.grpOrder = new System.Windows.Forms.GroupBox();
            this.pboItem = new System.Windows.Forms.PictureBox();
            this.btnDrop = new System.Windows.Forms.Button();
            this.txtShipping = new System.Windows.Forms.TextBox();
            this.lblShipping = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.nudQty = new System.Windows.Forms.NumericUpDown();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.btnAddTitle = new System.Windows.Forms.Button();
            this.lblTax = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.txtSubtotal = new System.Windows.Forms.TextBox();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.clbBooks = new System.Windows.Forms.CheckedListBox();
            this.cboTitle = new System.Windows.Forms.ComboBox();
            this.lblQty = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.lblISBN = new System.Windows.Forms.Label();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblFormTitle = new System.Windows.Forms.Label();
            this.btnConfirmOrder = new System.Windows.Forms.Button();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.txtFirstNameEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtLastNameEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtAddressEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtCityEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.cboStateEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtZipCodeEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtEmailEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtCcNameEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtCcNumberEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtCcCvcEP = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblProductOwner = new System.Windows.Forms.Label();
            this.lblProductVersion = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.t1pgCustomer = new System.Windows.Forms.TabPage();
            this.t2pgOrder = new System.Windows.Forms.TabPage();
            this.pboLink = new System.Windows.Forms.PictureBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.grpCustomer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCcExpYYYY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCcExpMM)).BeginInit();
            this.grpOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFirstNameEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLastNameEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddressEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCityEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboStateEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZipCodeEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCcNameEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCcNumberEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCcCvcEP)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.t1pgCustomer.SuspendLayout();
            this.t2pgOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboLink)).BeginInit();
            this.SuspendLayout();
            // 
            // txtFirstNameEPL
            // 
            this.txtFirstNameEPL.Location = new System.Drawing.Point(264, 96);
            this.txtFirstNameEPL.Name = "txtFirstNameEPL";
            this.txtFirstNameEPL.Size = new System.Drawing.Size(200, 23);
            this.txtFirstNameEPL.TabIndex = 0;
            this.txtFirstNameEPL.Text = "ErrorBlinkStyle.NeverBlink";
            // 
            // txtLastNameEPL
            // 
            this.txtLastNameEPL.Location = new System.Drawing.Point(0, 0);
            this.txtLastNameEPL.Name = "txtLastNameEPL";
            this.txtLastNameEPL.Size = new System.Drawing.Size(100, 23);
            this.txtLastNameEPL.TabIndex = 0;
            // 
            // txtAddressEPL
            // 
            this.txtAddressEPL.Location = new System.Drawing.Point(0, 0);
            this.txtAddressEPL.Name = "txtAddressEPL";
            this.txtAddressEPL.Size = new System.Drawing.Size(100, 23);
            this.txtAddressEPL.TabIndex = 0;
            // 
            // txtCityEPL
            // 
            this.txtCityEPL.Location = new System.Drawing.Point(0, 0);
            this.txtCityEPL.Name = "txtCityEPL";
            this.txtCityEPL.Size = new System.Drawing.Size(100, 23);
            this.txtCityEPL.TabIndex = 0;
            // 
            // cboStateEPL
            // 
            this.cboStateEPL.Location = new System.Drawing.Point(0, 0);
            this.cboStateEPL.Name = "cboStateEPL";
            this.cboStateEPL.Size = new System.Drawing.Size(100, 23);
            this.cboStateEPL.TabIndex = 0;
            // 
            // txtZipCodeEPL
            // 
            this.txtZipCodeEPL.Location = new System.Drawing.Point(0, 0);
            this.txtZipCodeEPL.Name = "txtZipCodeEPL";
            this.txtZipCodeEPL.Size = new System.Drawing.Size(100, 23);
            this.txtZipCodeEPL.TabIndex = 0;
            // 
            // txtEmailEPL
            // 
            this.txtEmailEPL.Location = new System.Drawing.Point(0, 0);
            this.txtEmailEPL.Name = "txtEmailEPL";
            this.txtEmailEPL.Size = new System.Drawing.Size(100, 23);
            this.txtEmailEPL.TabIndex = 0;
            // 
            // txtQtyEPL
            // 
            this.txtQtyEPL.Location = new System.Drawing.Point(0, 0);
            this.txtQtyEPL.Name = "txtQtyEPL";
            this.txtQtyEPL.Size = new System.Drawing.Size(100, 23);
            this.txtQtyEPL.TabIndex = 0;
            // 
            // txtCcNumberEPL
            // 
            this.txtCcNumberEPL.Location = new System.Drawing.Point(0, 0);
            this.txtCcNumberEPL.Name = "txtCcNumberEPL";
            this.txtCcNumberEPL.Size = new System.Drawing.Size(100, 23);
            this.txtCcNumberEPL.TabIndex = 0;
            // 
            // grpCustomer
            // 
            this.grpCustomer.Controls.Add(this.lblAlertCutomer);
            this.grpCustomer.Controls.Add(this.cboCustomer);
            this.grpCustomer.Controls.Add(this.btnCustomerAdd);
            this.grpCustomer.Controls.Add(this.btnCustomerSave);
            this.grpCustomer.Controls.Add(this.btnCustomerCancel);
            this.grpCustomer.Controls.Add(this.btnCustomerEdit);
            this.grpCustomer.Controls.Add(this.lblCustomer);
            this.grpCustomer.Controls.Add(this.txtCcCvc);
            this.grpCustomer.Controls.Add(this.txtPhone);
            this.grpCustomer.Controls.Add(this.lblCcCvc);
            this.grpCustomer.Controls.Add(this.lblPhone);
            this.grpCustomer.Controls.Add(this.nudCcExpYYYY);
            this.grpCustomer.Controls.Add(this.lblEmailOptional);
            this.grpCustomer.Controls.Add(this.nudCcExpMM);
            this.grpCustomer.Controls.Add(this.lblExpires);
            this.grpCustomer.Controls.Add(this.txtEmail);
            this.grpCustomer.Controls.Add(this.txtCcNumber);
            this.grpCustomer.Controls.Add(this.lblEmail);
            this.grpCustomer.Controls.Add(this.lblCcNumber);
            this.grpCustomer.Controls.Add(this.cboState);
            this.grpCustomer.Controls.Add(this.txtCcName);
            this.grpCustomer.Controls.Add(this.lblState);
            this.grpCustomer.Controls.Add(this.lblCcName);
            this.grpCustomer.Controls.Add(this.txtZipCode);
            this.grpCustomer.Controls.Add(this.lblCreditCard);
            this.grpCustomer.Controls.Add(this.lblZipCode);
            this.grpCustomer.Controls.Add(this.cboCreditCard);
            this.grpCustomer.Controls.Add(this.lblAlertOrderSummary);
            this.grpCustomer.Controls.Add(this.txtCity);
            this.grpCustomer.Controls.Add(this.lblCity);
            this.grpCustomer.Controls.Add(this.txtAddress);
            this.grpCustomer.Controls.Add(this.lblAddress);
            this.grpCustomer.Controls.Add(this.txtLastName);
            this.grpCustomer.Controls.Add(this.lblLastName);
            this.grpCustomer.Controls.Add(this.txtFirstName);
            this.grpCustomer.Controls.Add(this.lblFirstName);
            this.grpCustomer.Location = new System.Drawing.Point(4, 4);
            this.grpCustomer.Name = "grpCustomer";
            this.grpCustomer.Size = new System.Drawing.Size(368, 315);
            this.grpCustomer.TabIndex = 0;
            this.grpCustomer.TabStop = false;
            this.grpCustomer.Text = "CUSTOMER: {customer id}";
            this.grpCustomer.Leave += new System.EventHandler(this.grpCustomer_Leave);
            // 
            // lblAlertCutomer
            // 
            this.lblAlertCutomer.AutoSize = true;
            this.lblAlertCutomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblAlertCutomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlertCutomer.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblAlertCutomer.Location = new System.Drawing.Point(9, 166);
            this.lblAlertCutomer.Name = "lblAlertCutomer";
            this.lblAlertCutomer.Size = new System.Drawing.Size(305, 13);
            this.lblAlertCutomer.TabIndex = 13;
            this.lblAlertCutomer.Text = "..  The fastest way to get what you want! .. Pay by credit card ..";
            // 
            // cboCustomer
            // 
            this.cboCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCustomer.FormattingEnabled = true;
            this.cboCustomer.Location = new System.Drawing.Point(67, 25);
            this.cboCustomer.Name = "cboCustomer";
            this.cboCustomer.Size = new System.Drawing.Size(196, 21);
            this.cboCustomer.TabIndex = 1;
            this.cboCustomer.SelectedIndexChanged += new System.EventHandler(this.cboCustomer_SelectedIndexChanged);
            this.cboCustomer.Click += new System.EventHandler(this.cboCustomer_Click);
            // 
            // btnCustomerAdd
            // 
            this.btnCustomerAdd.Location = new System.Drawing.Point(260, 183);
            this.btnCustomerAdd.Name = "btnCustomerAdd";
            this.btnCustomerAdd.Size = new System.Drawing.Size(85, 23);
            this.btnCustomerAdd.TabIndex = 17;
            this.btnCustomerAdd.Text = "Add";
            this.btnCustomerAdd.UseVisualStyleBackColor = true;
            this.btnCustomerAdd.Click += new System.EventHandler(this.btnCustomerAdd_Click);
            // 
            // btnCustomerSave
            // 
            this.btnCustomerSave.Enabled = false;
            this.btnCustomerSave.Location = new System.Drawing.Point(260, 210);
            this.btnCustomerSave.Name = "btnCustomerSave";
            this.btnCustomerSave.Size = new System.Drawing.Size(85, 23);
            this.btnCustomerSave.TabIndex = 18;
            this.btnCustomerSave.Text = "Save";
            this.btnCustomerSave.UseVisualStyleBackColor = true;
            this.btnCustomerSave.Click += new System.EventHandler(this.btnCustomerSave_Click);
            // 
            // btnCustomerCancel
            // 
            this.btnCustomerCancel.Enabled = false;
            this.btnCustomerCancel.Location = new System.Drawing.Point(260, 237);
            this.btnCustomerCancel.Name = "btnCustomerCancel";
            this.btnCustomerCancel.Size = new System.Drawing.Size(85, 23);
            this.btnCustomerCancel.TabIndex = 19;
            this.btnCustomerCancel.Text = "Cancel";
            this.btnCustomerCancel.UseVisualStyleBackColor = true;
            this.btnCustomerCancel.Click += new System.EventHandler(this.btnCustomerCancel_Click);
            // 
            // btnCustomerEdit
            // 
            this.btnCustomerEdit.Enabled = false;
            this.btnCustomerEdit.Location = new System.Drawing.Point(261, 24);
            this.btnCustomerEdit.Name = "btnCustomerEdit";
            this.btnCustomerEdit.Size = new System.Drawing.Size(85, 23);
            this.btnCustomerEdit.TabIndex = 2;
            this.btnCustomerEdit.Text = "Edit";
            this.btnCustomerEdit.UseVisualStyleBackColor = true;
            this.btnCustomerEdit.Click += new System.EventHandler(this.btnCustomerEdit_Click);
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(16, 29);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(54, 13);
            this.lblCustomer.TabIndex = 43;
            this.lblCustomer.Text = "Customer:";
            // 
            // txtCcCvc
            // 
            this.txtCcCvc.Location = new System.Drawing.Point(167, 241);
            this.txtCcCvc.Name = "txtCcCvc";
            this.txtCcCvc.Size = new System.Drawing.Size(30, 20);
            this.txtCcCvc.TabIndex = 16;
            this.txtCcCvc.TextChanged += new System.EventHandler(this.txtCcCvc_Validated);
            this.txtCcCvc.Leave += new System.EventHandler(this.txtCcCvc_Validated);
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(67, 117);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(172, 20);
            this.txtPhone.TabIndex = 9;
            // 
            // lblCcCvc
            // 
            this.lblCcCvc.AutoSize = true;
            this.lblCcCvc.Location = new System.Drawing.Point(136, 244);
            this.lblCcCvc.Name = "lblCcCvc";
            this.lblCcCvc.Size = new System.Drawing.Size(31, 13);
            this.lblCcCvc.TabIndex = 42;
            this.lblCcCvc.Text = "CVC:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(22, 120);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(41, 13);
            this.lblPhone.TabIndex = 16;
            this.lblPhone.Text = "Phone:";
            // 
            // nudCcExpYYYY
            // 
            this.nudCcExpYYYY.Enabled = false;
            this.nudCcExpYYYY.Location = new System.Drawing.Point(84, 241);
            this.nudCcExpYYYY.Maximum = new decimal(new int[] {
            2016,
            0,
            0,
            0});
            this.nudCcExpYYYY.Minimum = new decimal(new int[] {
            2004,
            0,
            0,
            0});
            this.nudCcExpYYYY.Name = "nudCcExpYYYY";
            this.nudCcExpYYYY.Size = new System.Drawing.Size(44, 20);
            this.nudCcExpYYYY.TabIndex = 15;
            this.nudCcExpYYYY.Value = new decimal(new int[] {
            2014,
            0,
            0,
            0});
            this.nudCcExpYYYY.Click += new System.EventHandler(this.nudExpYYYY_Click);
            // 
            // lblEmailOptional
            // 
            this.lblEmailOptional.AutoSize = true;
            this.lblEmailOptional.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblEmailOptional.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailOptional.Location = new System.Drawing.Point(240, 139);
            this.lblEmailOptional.Name = "lblEmailOptional";
            this.lblEmailOptional.Size = new System.Drawing.Size(105, 13);
            this.lblEmailOptional.TabIndex = 14;
            this.lblEmailOptional.Text = "- - - Newsletter? (opt)";
            // 
            // nudCcExpMM
            // 
            this.nudCcExpMM.Enabled = false;
            this.nudCcExpMM.Location = new System.Drawing.Point(67, 241);
            this.nudCcExpMM.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nudCcExpMM.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCcExpMM.Name = "nudCcExpMM";
            this.nudCcExpMM.Size = new System.Drawing.Size(32, 20);
            this.nudCcExpMM.TabIndex = 14;
            this.nudCcExpMM.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.nudCcExpMM.Click += new System.EventHandler(this.nudExpMM_Click);
            this.nudCcExpMM.MouseClick += new System.Windows.Forms.MouseEventHandler(this.nudCcExpMM_MouseClick);
            // 
            // lblExpires
            // 
            this.lblExpires.AutoSize = true;
            this.lblExpires.Location = new System.Drawing.Point(24, 244);
            this.lblExpires.Name = "lblExpires";
            this.lblExpires.Size = new System.Drawing.Size(44, 13);
            this.lblExpires.TabIndex = 37;
            this.lblExpires.Text = "Expires:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(67, 136);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(172, 20);
            this.txtEmail.TabIndex = 10;
            this.txtEmail.Validated += new System.EventHandler(this.txtEmail_Validated);
            // 
            // txtCcNumber
            // 
            this.txtCcNumberEP.SetIconPadding(this.txtCcNumber, 2);
            this.txtCcNumber.Location = new System.Drawing.Point(67, 222);
            this.txtCcNumber.Name = "txtCcNumber";
            this.txtCcNumber.Size = new System.Drawing.Size(130, 20);
            this.txtCcNumber.TabIndex = 13;
            this.txtCcNumber.TextChanged += new System.EventHandler(this.txtCcNumber_Validated);
            this.txtCcNumber.Leave += new System.EventHandler(this.txtCcNumber_Validated);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(22, 139);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 12;
            this.lblEmail.Text = "Email:";
            // 
            // lblCcNumber
            // 
            this.lblCcNumber.AutoSize = true;
            this.lblCcNumber.Location = new System.Drawing.Point(21, 225);
            this.lblCcNumber.Name = "lblCcNumber";
            this.lblCcNumber.Size = new System.Drawing.Size(47, 13);
            this.lblCcNumber.TabIndex = 34;
            this.lblCcNumber.Text = "Number:";
            // 
            // cboState
            // 
            this.cboState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboState.FormattingEnabled = true;
            this.cboState.Items.AddRange(new object[] {
            "AL",
            "AK",
            "AZ",
            "CA",
            "CO",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY"});
            this.cboState.Location = new System.Drawing.Point(200, 90);
            this.cboState.Name = "cboState";
            this.cboState.Size = new System.Drawing.Size(39, 21);
            this.cboState.TabIndex = 7;
            this.cboState.TextChanged += new System.EventHandler(this.cboState_Validated);
            this.cboState.Leave += new System.EventHandler(this.cboState_Validated);
            // 
            // txtCcName
            // 
            this.txtCcNameEP.SetIconPadding(this.txtCcName, 2);
            this.txtCcName.Location = new System.Drawing.Point(67, 203);
            this.txtCcName.Name = "txtCcName";
            this.txtCcName.Size = new System.Drawing.Size(130, 20);
            this.txtCcName.TabIndex = 12;
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(168, 93);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(35, 13);
            this.lblState.TabIndex = 10;
            this.lblState.Text = "State:";
            // 
            // lblCcName
            // 
            this.lblCcName.AutoSize = true;
            this.lblCcName.Location = new System.Drawing.Point(30, 206);
            this.lblCcName.Name = "lblCcName";
            this.lblCcName.Size = new System.Drawing.Size(38, 13);
            this.lblCcName.TabIndex = 32;
            this.lblCcName.Text = "Name:";
            // 
            // txtZipCode
            // 
            this.txtZipCode.Location = new System.Drawing.Point(280, 90);
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(65, 20);
            this.txtZipCode.TabIndex = 8;
            this.txtZipCode.Leave += new System.EventHandler(this.txtZipCode_Validated);
            this.txtZipCode.Validated += new System.EventHandler(this.txtZipCode_Validated);
            // 
            // lblCreditCard
            // 
            this.lblCreditCard.AutoSize = true;
            this.lblCreditCard.Location = new System.Drawing.Point(21, 186);
            this.lblCreditCard.Name = "lblCreditCard";
            this.lblCreditCard.Size = new System.Drawing.Size(62, 13);
            this.lblCreditCard.TabIndex = 31;
            this.lblCreditCard.Text = "Credit Card:";
            // 
            // lblZipCode
            // 
            this.lblZipCode.AutoSize = true;
            this.lblZipCode.Location = new System.Drawing.Point(256, 93);
            this.lblZipCode.Name = "lblZipCode";
            this.lblZipCode.Size = new System.Drawing.Size(25, 13);
            this.lblZipCode.TabIndex = 8;
            this.lblZipCode.Text = "Zip:";
            // 
            // cboCreditCard
            // 
            this.cboCreditCard.FormattingEnabled = true;
            this.cboCreditCard.Items.AddRange(new object[] {
            "Visa",
            "Mastercard",
            "Discover",
            "Diners Club",
            "American Express"});
            this.cboCreditCard.Location = new System.Drawing.Point(84, 183);
            this.cboCreditCard.Name = "cboCreditCard";
            this.cboCreditCard.Size = new System.Drawing.Size(113, 21);
            this.cboCreditCard.TabIndex = 11;
            // 
            // lblAlertOrderSummary
            // 
            this.lblAlertOrderSummary.AutoSize = true;
            this.lblAlertOrderSummary.Location = new System.Drawing.Point(2, 262);
            this.lblAlertOrderSummary.Name = "lblAlertOrderSummary";
            this.lblAlertOrderSummary.Size = new System.Drawing.Size(355, 13);
            this.lblAlertOrderSummary.TabIndex = 29;
            this.lblAlertOrderSummary.Text = "................................................................................." +
    "...................................";
            this.lblAlertOrderSummary.Visible = false;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(67, 90);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(90, 20);
            this.txtCity.TabIndex = 6;
            this.txtCity.TextChanged += new System.EventHandler(this.txtCity_Validated);
            this.txtCity.Leave += new System.EventHandler(this.txtCity_Validated);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(42, 93);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(27, 13);
            this.lblCity.TabIndex = 6;
            this.lblCity.Text = "City:";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(67, 71);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(278, 20);
            this.txtAddress.TabIndex = 5;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_Validated);
            this.txtAddress.Leave += new System.EventHandler(this.txtAddress_Validated);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(22, 74);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(48, 13);
            this.lblAddress.TabIndex = 4;
            this.lblAddress.Text = "Address:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(226, 52);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(119, 20);
            this.txtLastName.TabIndex = 4;
            this.txtLastName.TextChanged += new System.EventHandler(this.txtLastName_Validated);
            this.txtLastName.Leave += new System.EventHandler(this.txtLastName_Validated);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(168, 55);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstNameEP.SetIconPadding(this.txtFirstName, 2);
            this.txtFirstName.Location = new System.Drawing.Point(67, 52);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(90, 20);
            this.txtFirstName.TabIndex = 3;
            this.txtFirstName.TextChanged += new System.EventHandler(this.txtFirstName_Validated);
            this.txtFirstName.Leave += new System.EventHandler(this.txtFirstName_Validated);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(10, 55);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            // 
            // grpOrder
            // 
            this.grpOrder.Controls.Add(this.pboItem);
            this.grpOrder.Controls.Add(this.btnDrop);
            this.grpOrder.Controls.Add(this.txtShipping);
            this.grpOrder.Controls.Add(this.lblShipping);
            this.grpOrder.Controls.Add(this.txtTotal);
            this.grpOrder.Controls.Add(this.nudQty);
            this.grpOrder.Controls.Add(this.lblTotal);
            this.grpOrder.Controls.Add(this.txtTax);
            this.grpOrder.Controls.Add(this.btnAddTitle);
            this.grpOrder.Controls.Add(this.lblTax);
            this.grpOrder.Controls.Add(this.txtCost);
            this.grpOrder.Controls.Add(this.txtSubtotal);
            this.grpOrder.Controls.Add(this.lblSubtotal);
            this.grpOrder.Controls.Add(this.lblCost);
            this.grpOrder.Controls.Add(this.clbBooks);
            this.grpOrder.Controls.Add(this.cboTitle);
            this.grpOrder.Controls.Add(this.lblQty);
            this.grpOrder.Controls.Add(this.txtPrice);
            this.grpOrder.Controls.Add(this.lblPrice);
            this.grpOrder.Controls.Add(this.lblTitle);
            this.grpOrder.Controls.Add(this.txtISBN);
            this.grpOrder.Controls.Add(this.lblISBN);
            this.grpOrder.Controls.Add(this.txtAuthor);
            this.grpOrder.Controls.Add(this.lblAuthor);
            this.grpOrder.Location = new System.Drawing.Point(4, 4);
            this.grpOrder.Name = "grpOrder";
            this.grpOrder.Size = new System.Drawing.Size(368, 315);
            this.grpOrder.TabIndex = 1;
            this.grpOrder.TabStop = false;
            this.grpOrder.Text = "ORDER: {order number}";
            this.grpOrder.Enter += new System.EventHandler(this.grpBook_Enter);
            // 
            // pboItem
            // 
            this.pboItem.BackgroundImage = global::ArkhamBooks.Properties.Resources.ImgTextbook_JSP2;
            this.pboItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pboItem.InitialImage = null;
            this.pboItem.Location = new System.Drawing.Point(12, 209);
            this.pboItem.Name = "pboItem";
            this.pboItem.Size = new System.Drawing.Size(200, 100);
            this.pboItem.TabIndex = 30;
            this.pboItem.TabStop = false;
            this.pboItem.UseWaitCursor = true;
            // 
            // btnDrop
            // 
            this.btnDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDrop.Location = new System.Drawing.Point(12, 72);
            this.btnDrop.Name = "btnDrop";
            this.btnDrop.Size = new System.Drawing.Size(57, 21);
            this.btnDrop.TabIndex = 3;
            this.btnDrop.Text = "DROP";
            this.btnDrop.UseVisualStyleBackColor = true;
            this.btnDrop.Click += new System.EventHandler(this.btnDrop_Click);
            // 
            // txtShipping
            // 
            this.txtShipping.Enabled = false;
            this.txtShipping.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShipping.Location = new System.Drawing.Point(294, 228);
            this.txtShipping.Name = "txtShipping";
            this.txtShipping.Size = new System.Drawing.Size(62, 20);
            this.txtShipping.TabIndex = 12;
            this.txtShipping.TabStop = false;
            // 
            // lblShipping
            // 
            this.lblShipping.AutoSize = true;
            this.lblShipping.Location = new System.Drawing.Point(245, 231);
            this.lblShipping.Name = "lblShipping";
            this.lblShipping.Size = new System.Drawing.Size(51, 13);
            this.lblShipping.TabIndex = 28;
            this.lblShipping.Text = "Shipping:";
            this.lblShipping.Click += new System.EventHandler(this.lblShipping_Click);
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(294, 266);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(62, 20);
            this.txtTotal.TabIndex = 14;
            this.txtTotal.TabStop = false;
            // 
            // nudQty
            // 
            this.nudQty.Location = new System.Drawing.Point(204, 71);
            this.nudQty.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.nudQty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudQty.Name = "nudQty";
            this.nudQty.Size = new System.Drawing.Size(35, 20);
            this.nudQty.TabIndex = 7;
            this.nudQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudQty.ValueChanged += new System.EventHandler(this.nudQty_Validated);
            this.nudQty.Leave += new System.EventHandler(this.nudQty_Leave);
            this.nudQty.Validated += new System.EventHandler(this.nudQty_Validated);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(262, 269);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(34, 13);
            this.lblTotal.TabIndex = 26;
            this.lblTotal.Text = "Total:";
            // 
            // txtTax
            // 
            this.txtTax.Enabled = false;
            this.txtTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTax.Location = new System.Drawing.Point(294, 247);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(62, 20);
            this.txtTax.TabIndex = 13;
            this.txtTax.TabStop = false;
            // 
            // btnAddTitle
            // 
            this.btnAddTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTitle.Location = new System.Drawing.Point(300, 24);
            this.btnAddTitle.Name = "btnAddTitle";
            this.btnAddTitle.Size = new System.Drawing.Size(58, 23);
            this.btnAddTitle.TabIndex = 2;
            this.btnAddTitle.Text = " ADD";
            this.btnAddTitle.UseVisualStyleBackColor = true;
            this.btnAddTitle.Click += new System.EventHandler(this.btnAddTitle_Click);
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Location = new System.Drawing.Point(230, 250);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(66, 13);
            this.lblTax.TabIndex = 24;
            this.lblTax.Text = "(7.75%) Tax:";
            // 
            // txtCost
            // 
            this.txtCost.Enabled = false;
            this.txtCost.Location = new System.Drawing.Point(300, 71);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(58, 20);
            this.txtCost.TabIndex = 8;
            this.txtCost.TabStop = false;
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.Enabled = false;
            this.txtSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubtotal.Location = new System.Drawing.Point(294, 209);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.Size = new System.Drawing.Size(62, 20);
            this.txtSubtotal.TabIndex = 11;
            this.txtSubtotal.TabStop = false;
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Location = new System.Drawing.Point(247, 212);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(49, 13);
            this.lblSubtotal.TabIndex = 22;
            this.lblSubtotal.Text = "Subtotal:";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(272, 74);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(31, 13);
            this.lblCost.TabIndex = 27;
            this.lblCost.Text = "Cost:";
            // 
            // clbBooks
            // 
            this.clbBooks.BackColor = System.Drawing.SystemColors.MenuBar;
            this.clbBooks.FormattingEnabled = true;
            this.clbBooks.Location = new System.Drawing.Point(12, 102);
            this.clbBooks.Name = "clbBooks";
            this.clbBooks.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.clbBooks.Size = new System.Drawing.Size(346, 94);
            this.clbBooks.TabIndex = 9;
            this.clbBooks.TabStop = false;
            this.clbBooks.SelectedIndexChanged += new System.EventHandler(this.clbBooks_SelectedIndexChanged);
            // 
            // cboTitle
            // 
            this.cboTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTitle.FormattingEnabled = true;
            this.cboTitle.Location = new System.Drawing.Point(67, 25);
            this.cboTitle.Name = "cboTitle";
            this.cboTitle.Size = new System.Drawing.Size(234, 21);
            this.cboTitle.TabIndex = 1;
            this.cboTitle.SelectedIndexChanged += new System.EventHandler(this.cboTitle_SelectedIndexChanged);
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(180, 74);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(26, 13);
            this.lblQty.TabIndex = 22;
            this.lblQty.Text = "Qty:";
            // 
            // txtPrice
            // 
            this.txtPrice.Enabled = false;
            this.txtPrice.Location = new System.Drawing.Point(119, 71);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(53, 20);
            this.txtPrice.TabIndex = 6;
            this.txtPrice.TabStop = false;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(87, 74);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(34, 13);
            this.lblPrice.TabIndex = 20;
            this.lblPrice.Text = "Price:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(39, 29);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(30, 13);
            this.lblTitle.TabIndex = 18;
            this.lblTitle.Text = "Title:";
            // 
            // txtISBN
            // 
            this.txtISBN.Enabled = false;
            this.txtISBN.Location = new System.Drawing.Point(276, 52);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(82, 20);
            this.txtISBN.TabIndex = 5;
            this.txtISBN.TabStop = false;
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Location = new System.Drawing.Point(243, 55);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(35, 13);
            this.lblISBN.TabIndex = 16;
            this.lblISBN.Text = "ISBN:";
            // 
            // txtAuthor
            // 
            this.txtAuthor.Enabled = false;
            this.txtAuthor.Location = new System.Drawing.Point(119, 52);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(120, 20);
            this.txtAuthor.TabIndex = 4;
            this.txtAuthor.TabStop = false;
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(80, 55);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(41, 13);
            this.lblAuthor.TabIndex = 13;
            this.lblAuthor.Text = "Author:";
            // 
            // lblFormTitle
            // 
            this.lblFormTitle.AutoSize = true;
            this.lblFormTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormTitle.Location = new System.Drawing.Point(87, 3);
            this.lblFormTitle.Name = "lblFormTitle";
            this.lblFormTitle.Size = new System.Drawing.Size(216, 20);
            this.lblFormTitle.TabIndex = 29;
            this.lblFormTitle.Text = "ArkhamBooks Order Form";
            this.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConfirmOrder
            // 
            this.btnConfirmOrder.Enabled = false;
            this.btnConfirmOrder.Location = new System.Drawing.Point(95, 385);
            this.btnConfirmOrder.Name = "btnConfirmOrder";
            this.btnConfirmOrder.Size = new System.Drawing.Size(85, 23);
            this.btnConfirmOrder.TabIndex = 51;
            this.btnConfirmOrder.Text = "Confirm Order";
            this.btnConfirmOrder.UseVisualStyleBackColor = true;
            this.btnConfirmOrder.Click += new System.EventHandler(this.btnConfirmOrder_Click);
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.Enabled = false;
            this.btnCancelOrder.Location = new System.Drawing.Point(220, 385);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(85, 23);
            this.btnCancelOrder.TabIndex = 52;
            this.btnCancelOrder.Text = "Cancel Order";
            this.btnCancelOrder.UseVisualStyleBackColor = true;
            this.btnCancelOrder.Click += new System.EventHandler(this.btnCancelOrder_Click);
            // 
            // txtFirstNameEP
            // 
            this.txtFirstNameEP.BlinkRate = 1000;
            this.txtFirstNameEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtFirstNameEP.ContainerControl = this;
            // 
            // txtLastNameEP
            // 
            this.txtLastNameEP.BlinkRate = 1000;
            this.txtLastNameEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtLastNameEP.ContainerControl = this;
            // 
            // txtAddressEP
            // 
            this.txtAddressEP.BlinkRate = 1000;
            this.txtAddressEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtAddressEP.ContainerControl = this;
            // 
            // txtCityEP
            // 
            this.txtCityEP.BlinkRate = 1000;
            this.txtCityEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtCityEP.ContainerControl = this;
            // 
            // cboStateEP
            // 
            this.cboStateEP.BlinkRate = 1000;
            this.cboStateEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.cboStateEP.ContainerControl = this;
            // 
            // txtZipCodeEP
            // 
            this.txtZipCodeEP.BlinkRate = 1000;
            this.txtZipCodeEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtZipCodeEP.ContainerControl = this;
            // 
            // txtEmailEP
            // 
            this.txtEmailEP.BlinkRate = 1000;
            this.txtEmailEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtEmailEP.ContainerControl = this;
            // 
            // txtCcNameEP
            // 
            this.txtCcNameEP.BlinkRate = 1000;
            this.txtCcNameEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtCcNameEP.ContainerControl = this;
            // 
            // txtCcNumberEP
            // 
            this.txtCcNumberEP.BlinkRate = 1000;
            this.txtCcNumberEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtCcNumberEP.ContainerControl = this;
            // 
            // txtCcCvcEP
            // 
            this.txtCcCvcEP.BlinkRate = 1000;
            this.txtCcCvcEP.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.txtCcCvcEP.ContainerControl = this;
            // 
            // lblProductOwner
            // 
            this.lblProductOwner.AutoSize = true;
            this.lblProductOwner.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductOwner.Location = new System.Drawing.Point(7, 412);
            this.lblProductOwner.Name = "lblProductOwner";
            this.lblProductOwner.Size = new System.Drawing.Size(96, 13);
            this.lblProductOwner.TabIndex = 29;
            this.lblProductOwner.Text = "Coleman University";
            // 
            // lblProductVersion
            // 
            this.lblProductVersion.AutoSize = true;
            this.lblProductVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductVersion.Location = new System.Drawing.Point(205, 412);
            this.lblProductVersion.Name = "lblProductVersion";
            this.lblProductVersion.Size = new System.Drawing.Size(178, 13);
            this.lblProductVersion.TabIndex = 32;
            this.lblProductVersion.Text = "COM270 Project05v1-ArkhamBooks ";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.t1pgCustomer);
            this.tabControl1.Controls.Add(this.t2pgOrder);
            this.tabControl1.Location = new System.Drawing.Point(1, 26);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(386, 350);
            this.tabControl1.TabIndex = 33;
            // 
            // t1pgCustomer
            // 
            this.t1pgCustomer.Controls.Add(this.grpCustomer);
            this.t1pgCustomer.Location = new System.Drawing.Point(4, 22);
            this.t1pgCustomer.Name = "t1pgCustomer";
            this.t1pgCustomer.Padding = new System.Windows.Forms.Padding(3);
            this.t1pgCustomer.Size = new System.Drawing.Size(378, 324);
            this.t1pgCustomer.TabIndex = 0;
            this.t1pgCustomer.Text = "Customer Data";
            this.t1pgCustomer.UseVisualStyleBackColor = true;
            // 
            // t2pgOrder
            // 
            this.t2pgOrder.Controls.Add(this.grpOrder);
            this.t2pgOrder.Location = new System.Drawing.Point(4, 22);
            this.t2pgOrder.Name = "t2pgOrder";
            this.t2pgOrder.Padding = new System.Windows.Forms.Padding(3);
            this.t2pgOrder.Size = new System.Drawing.Size(378, 324);
            this.t2pgOrder.TabIndex = 1;
            this.t2pgOrder.Text = "Order Data - Shopping Cart";
            this.t2pgOrder.UseVisualStyleBackColor = true;
            this.t2pgOrder.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // pboLink
            // 
            this.pboLink.Image = global::ArkhamBooks.Properties.Resources.linked;
            this.pboLink.Location = new System.Drawing.Point(335, 7);
            this.pboLink.Name = "pboLink";
            this.pboLink.Size = new System.Drawing.Size(42, 35);
            this.pboLink.TabIndex = 53;
            this.pboLink.TabStop = false;
            this.pboLink.UseWaitCursor = true;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblInfo.Font = new System.Drawing.Font("Papyrus", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.ForeColor = System.Drawing.Color.Red;
            this.lblInfo.Location = new System.Drawing.Point(320, 387);
            this.lblInfo.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(48, 18);
            this.lblInfo.TabIndex = 54;
            this.lblInfo.Text = "About";
            this.lblInfo.Click += new System.EventHandler(this.lblInfo_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // frmOrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(385, 428);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.pboLink);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblProductVersion);
            this.Controls.Add(this.lblProductOwner);
            this.Controls.Add(this.btnCancelOrder);
            this.Controls.Add(this.btnConfirmOrder);
            this.Controls.Add(this.lblFormTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmOrderForm";
            this.Text = "ArkhamBooks Order Form";
            this.Load += new System.EventHandler(this.frmOrderForm_Load);
            this.grpCustomer.ResumeLayout(false);
            this.grpCustomer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCcExpYYYY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCcExpMM)).EndInit();
            this.grpOrder.ResumeLayout(false);
            this.grpOrder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFirstNameEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLastNameEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddressEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCityEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboStateEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZipCodeEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCcNameEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCcNumberEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCcCvcEP)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.t1pgCustomer.ResumeLayout(false);
            this.t2pgOrder.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pboLink)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCustomer;
        protected System.Windows.Forms.TextBox txtZipCode;
        private System.Windows.Forms.Label txtZipCodeEPL;
        private System.Windows.Forms.Label lblZipCode;
        protected System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label txtCityEPL;
        private System.Windows.Forms.Label lblCity;
        protected System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label txtAddressEPL;
        private System.Windows.Forms.Label lblAddress;
        protected System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label txtLastNameEPL;
        private System.Windows.Forms.Label lblLastName;
        protected System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label txtFirstNameEPL;
        private System.Windows.Forms.Label lblFirstName;
        protected System.Windows.Forms.ComboBox cboState;
        private System.Windows.Forms.Label cboStateEPL;
        private System.Windows.Forms.Label lblState;
        protected System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label txtEmailEPL;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.GroupBox grpOrder;
        private System.Windows.Forms.ComboBox cboTitle;
        private System.Windows.Forms.Label txtQtyEPL;
        private System.Windows.Forms.Label lblQty;
        protected System.Windows.Forms.TextBox txtCcNumber;
        private System.Windows.Forms.Label txtCcNumberEPL;
        private System.Windows.Forms.Label lblCcNumber;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Button btnAddTitle;
        protected System.Windows.Forms.CheckedListBox clbBooks;
        protected System.Windows.Forms.TextBox txtSubtotal;
        private System.Windows.Forms.Label lblSubtotal;
        protected System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblTotal;
        protected System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.Label lblTax;
        protected System.Windows.Forms.TextBox txtShipping;
        private System.Windows.Forms.Label lblShipping;
        private System.Windows.Forms.Label lblFormTitle;
        private System.Windows.Forms.Button btnConfirmOrder;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Label lblProductVersion;
        private System.Windows.Forms.Label lblProductOwner;
        private System.Windows.Forms.Label lblAlertCutomer;
        private System.Windows.Forms.Label lblAlertOrderSummary;
        private NumericUpDown nudQty;
        private Label lblEmailOptional;
        private Label lblCreditCard;
        private ComboBox cboCreditCard;
        protected TextBox txtCcName;
        private Label lblCcName;
        private Label lblExpires;
        private NumericUpDown nudCcExpMM;
        private NumericUpDown nudCcExpYYYY;
        protected TextBox txtCcCvc;
        private Label lblCcCvc;
        protected TextBox txtPhone;
        private Label lblPhone;
        private TabControl tabControl1;
        private TabPage t1pgCustomer;
        private TabPage t2pgOrder;
        private Button btnCustomerAdd;
        private Button btnCustomerSave;
        private Button btnCustomerCancel;
        private Button btnCustomerEdit;
        private Label lblCustomer;
        private ComboBox cboCustomer;
        private Button btnDrop;
        private PictureBox pboItem;
        private PictureBox pboLink;
        private Label lblInfo;
        private PrintDialog printDialog1;

        public System.EventHandler lblQty_Click { get; set; }

    }
}

