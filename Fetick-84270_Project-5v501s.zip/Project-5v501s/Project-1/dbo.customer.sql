﻿INSERT INTO [dbo].[Customer] ([CustId], [LastName], [FirstName], [Address], [City], [State], [Zip], [Phone], [Email], [CardType], [CardNumber], [CardExpire]) 
VALUES 
(NEWID(), N'Richardson', N'John', N'1524 Center Dr.', N'La Mesa', N'CA', N'91945', N'619-358-6578', N'jrich@cox.net', N'Visa', N'4224369865742591', N'03/07'),
(NEWID(), N'Lolan', N'Bobbi', N'122 Elysian Fields', N'New Orleans', N'LA', N'73401', N'704-987-6421', N'blolan@no.rr.net', N'Master Card', N'5623326598754128', N'02/05'),
(NEWID(), N'Smith', N'Tim', N'12597 1st Ave.', N'Chula Vista', N'CA', N'92174', N'619-658-8794', N'tsmith@sbcglobal.net', N'Discover', N'6598234568710954', N'04/06'),
(NEWID(), N'Edwards', N'Mitch', N'19872 Pine Court', N'Kansas City', N'MO', N'69877', N'648-987-0938', N'mitch@earthnet.com', N'American Express', N'370044875669745', N'10/04'),
(NEWID(), N'Brown', N'Edward', N'14598 Poway Road', N'Poway', N'CA', N'92064', N'858-486-6897', N'ebrown@hobo.net', N'Master Card', N'5236698756824712', N'09/05'),
(NEWID(), N'Rowland', N'Mike', N'32657 Jasmine Place', N'Park City', N'UT', N'86987', N'236-568-9874', N'roland@hotmail.com', N'Visa', N'4225639856875214', N'12/04'),
(NEWID(), N'Perkins', N'Anthony', N'235 Circle Dr.', N'La Mesa', N'CA', N'91942', N'247-986-3274', N'psycho@bates.com', N'Master Card', N'5668213659875897', N'12/05'),
(NEWID(), N'Jones', N'Ralph', N'2 Shady Lane', N'Chula Vista', N'CA', N'92105', N'254-987-2327', N'shady@nightmare.com', N'Discover', N'6987986215476387', N'01/07');
