﻿CREATE TABLE [dbo].[Customer]
(
	[CustId] INT NOT NULL PRIMARY KEY,
	[LastName] varchar(20) NOT NULL, 
	[FirstName] varchar(15) NOT NULL, 
	[Address] varchar(30) default NULL, 
	[City] varchar(20) default NULL, 
	[State] varchar(20) default NULL, 
	[Zip] varchar(10) default NULL, 
	[Phone] varchar(12) default NULL, 
	[Email] varchar(35) default NULL, 
	[CardType] varchar(16) default NULL, 
	[CardNumber] varchar(16) default NULL, 
	[CardExpire] varchar(5) default NULL) 
)
