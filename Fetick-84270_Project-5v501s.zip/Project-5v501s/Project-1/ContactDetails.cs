﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArkhamBooks
{
    public class ContactDetails : IComparable<ContactDetails>
    {
        public ContactDetails() { }
        // Constructor for the Contact object
        public ContactDetails(string custId,
                              string firstName,
                              string lastName,
                              string address,
                              string city, 
                              string state,
                              string zipCode,
                              string phone,
                              string email,
                              string cardType,
                              string cardNumber,
                              string cardExpire)
        {
            CustId = custId;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            City = city;
            State = state;
            ZipCode = zipCode;
            Phone = phone;
            Email = email;
            CardType = cardType;
            CardNumber = cardNumber;
            CardExpire = cardExpire;
        }
        // Properties of the Contact object
        private string custId;
        public string CustId
        {
            get { return custId; }
            set { custId = value; }
        }
        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        private string address;
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        private string city;
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        private string state;
        public string State
        {
            get { return state; }
            set { state = value; }
        }
        private string zipCode;
        public string ZipCode
        {
            get { return zipCode; }
            set { zipCode = value; }
        }
        private string phone;
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }
        private string email;
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        private string cardType;
        public string CardType
        {
            get { return cardType; }
            set { cardType = value; }
        }
        private string cardNumber;
        public string CardNumber
        {
            get { return cardNumber; }
            set { cardNumber = value; }
        }
        protected string cardExpire;
        public string CardExpire
        {
            get { return cardExpire; }
            set { cardExpire = value; }
        }
        // Implement the IComparable interface to override the CompareTo method
        //   with a comparison of the Customer's lastName and firstName properties
        public int CompareTo(ContactDetails obj)
        {
            int returnVal;

            // Comparing the lastName
            if (this.lastName.CompareTo(obj.LastName) > 0)
            { returnVal = 1; }
            else
            {   // Not greater than zero, evaluate further
                if (this.lastName.CompareTo(obj.LastName) == 0)
                {
                    // matches lastName, so compare further with the firstName
                    if (this.firstName.CompareTo(obj.FirstName) > 0)
                    { returnVal = 1; }
                    else
                    {   // Not greater than zero, evaluate further
                        if (this.firstName.CompareTo(obj.FirstName) == 0)
                        { returnVal = 0; }
                        else
                        {   // Not equal to zero
                            returnVal = -1; 
                        }
                    }
                }
                else
                {   // Not equal to zero
                    returnVal = -1; 
                }
            }
            return returnVal;
        }

        public override string ToString()
        {
            return this.LastName + ", " + FirstName;
        }
    }
}
