﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArkhamBooks
{
    class ItemDetails : BookDetails, IComparable<BookDetails>
    {
        public ItemDetails() { }
        // Constructor for the ListItem object
        public ItemDetails(string isbn, string title, string author, decimal price, int qty)
        {
            // Incorporate the BookDetails
            Isbn = isbn;
            Title = title;
            Author = author;
            Price = price;
            // Incorporate the ListItem quantity
            Qty = qty;
        }
        private int qty;
        public int Qty
        {
            get { return qty; }
            set { qty = value; }
        }
        // Enum itemType for future expansion to items of other media
        private enum itemType { Book };
    }
}
