﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.IO;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArkhamBooks
{
    //public class ContactList : IComparable<ContactList>
    public class ContactList
    {
/*
        public ContactList() { }
        // Constructor for the ContactList object
        public ContactList(List<ContactDetails> contactList)
        {
            // Add the contact to the List of contacts
            List<ContactDetails> customer = new List<ContactDetails>();
        }

        private List<ContactDetails> customer;
        internal List<ContactDetails> Customer
        {
            get { return customer; }
            set { customer = value; }
        }

        // Implement the IComparable interface to override the CompareTo method
        //   with a comparison of the Order's lastName and firstName properties
        public int CompareTo(ContactList obj)
        {
            int returnVal;

            // Comparing the lastName
            if (this.customer.CompareTo(obj.Customer) > 0)
            { returnVal = 1; }
            else
            {   // Not greater than zero, evaluate further
                if (this.lastName.CompareTo(obj.LastName) == 0)
                {
                    // matches lastName, so compare further with the firstName
                    if (this.firstName.CompareTo(obj.FirstName) > 0)
                    { returnVal = 1; }
                    else
                    {   // Not greater than zero, evaluate further
                        if (this.firstName.CompareTo(obj.FirstName) == 0)
                        { returnVal = 0; }
                        else
                        {   // Not equal to zero
                            returnVal = -1;
                        }
                    }
                }
                else
                {   // Not equal to zero
                    returnVal = -1;
                }
            }
            return returnVal;
        }

        public override string ToString()
        {
            return this.LastName + ", " + FirstName;
        }
    }
 

    /*
    public class ContactProcessing
    {
        // Build an ArrayList to return to Form1
        private List<ContactDetails> contactList;
        //private List<ContactDetails> contactList = new List<ContactDetails>();
        private List<ContactDetails> ContactList
        {
            get { return contactList; }
            set { contactList = value; }
        }

        // Build an ArrayList to return to Form1
        public static List<ContactDetails> ReadContactData
        {
            /*
             * Not Implemented
             * 
            // Pg528. Reading from a sequential access text file
            // declare a delimiter, an input text file, and some arrays
            // 
            // Instantiate a book object and assign the fields
            // in each line of data to the attributes of a book
            public ContactDetails contact = new ContactDetails(txtFirstName.Text, lastName, address, city, state, zipCode);
            ContactDetails contact = new ContactDetails();
        
            contact(FirstName, lastName, address, city, state, zipCode);
                        
            // Add the contact to the ArrayList of contacts
            contactList.Add(contact);
            contactList.Sort();
            return ContactList;
        }
*/
    }

}
