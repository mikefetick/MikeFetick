﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 *
 * At the beginning of the following methods:
 *   AddCustomerData, UpdateCustomerData, and ReadListData
 * select a connection between AtHome or AtSchool
 *               //conn = GetConnectionAtHome();
 *               conn = GetConnectionAtSchool();
 */
using System;
using System.IO;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace ArkhamBooks
{
    public partial class DatabaseProcessing
    {
        // Build an ArrayList to return to Form1
        public static List<ContactDetails> ReadListData()
        {
            List<ContactDetails> itemList = new List<ContactDetails>();

            string connState;
            SqlConnection conn = null;
            SqlDataReader reader = null;
            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                string query = @"SELECT CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, CardType, CardNumber, CardExpire FROM Customer";

                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                connState = conn.State.ToString();
                if (!connState.Equals("Open"))
                {
                    MessageBox.Show(connState);
                }

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    itemList.Add(new ContactDetails(
                                         reader["CustId"].ToString(),
                                         reader["FirstName"].ToString(),
                                         reader["LastName"].ToString(),
                                         reader["Address"].ToString(),
                                         reader["City"].ToString(),
                                         reader["State"].ToString(),
                                         reader["Zip"].ToString(),
                                         reader["Phone"].ToString(),
                                         reader["Email"].ToString(),
                                         reader["CardType"].ToString(),
                                         reader["CardNumber"].ToString(),
                                         reader["CardExpire"].ToString()));
                    itemList.Sort();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return itemList;
        }

        public static SqlConnection GetConnectionAtHome()
        {
            //  Create... Connection
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            /* TO CONNECT AT HOME - LOCALHOST
             */
            builder.DataSource = @"(localdb)\Projects";
            builder.InitialCatalog = "db84270";
            builder.IntegratedSecurity = true;
            builder.ConnectTimeout = 30;
            builder.Encrypt = false;
            builder.TrustServerCertificate = false;
            //
            return new SqlConnection(builder.ConnectionString);
        }

        public static SqlConnection GetConnectionAtSchool()
        {
            //  Create... Connection
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            /* TO CONNECT AT SCHOOL - COLEMAN UNIVERSITY
             */
            builder.DataSource = "mssql-2-34";
            builder.UserID = "db84270";
            builder.InitialCatalog = "db84270";
            builder.Password = "5a0c1de0";
            //
            return new SqlConnection(builder.ConnectionString);
        }

        public static string AddOrderData(OrderDetails order)
        {
            SqlConnection conn = null;
            SqlDataAdapter adapter = null;
            SqlDataAdapter adapter1 = null;
            SqlDataAdapter adapter2 = null;
            SqlDataReader reader = null;
            string FK_CustomerOrderId = "";

            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                // Customer table already has existing customer record 
                // identified with Customer.CustId //RetrieveIdentity(conn);

                // Build SqlDataAdapter (adapter1) to update the CustomerOrders table 
                // Create a SqlDataAdapter based on a SELECT query.
                adapter1 =
                    new SqlDataAdapter(
                    @"SELECT CustomerOrderId, DateOrdered, Subtotal, Taxes, Shipping, Total, CustId FROM CustomerOrders",
                    conn);

                // CustomerOrders table gets one record inserted, 
                // from the Order, with the Customer's Id
                string insertSQLstmt1 = @"INSERT INTO CustomerOrders "
                                      + "(CustomerOrderId, DateOrdered, Subtotal, Taxes, Shipping, "
                                      + "Total, CustId) "
                                      + "VALUES "
                                      + "(NEWID(), "
                                      + "'" + order.OrderDate + "', "
                                      + "'" + order.Subtotal + "', "
                                      + "'" + order.Taxes + "', "
                                      + "'" + order.Shipping + "', "
                                      + "'" + order.Total + "', "
                                      + "'" + order.Customer.CustId + "')";

                //Create the SqlCommand to execute the Insert Sql statement.
                adapter1.InsertCommand = new SqlCommand(insertSQLstmt1, conn);
                adapter1.InsertCommand.CommandType = CommandType.Text;

                // Add the parameter for the LastName. Specifying the
                // ParameterDirection for an input parameter is not required.
                adapter1.InsertCommand.Parameters.Add(
                    new SqlParameter("@CustId", SqlDbType.UniqueIdentifier, 0, "CustId"));

                // Add the SqlParameter to retrieve the new identity value.
                // Specify the ParameterDirection as Output.
                SqlParameter parameter =
                    adapter1.InsertCommand.Parameters.Add(
                    "@CustomerOrderId", SqlDbType.UniqueIdentifier, 0, "NEWID()");
                parameter.Direction = ParameterDirection.Output;

                // Create a DataTable and fill it.
                System.Data.DataTable CustomerOrders = new DataTable();
                adapter1.Fill(CustomerOrders);

                // Add a new row. 
                DataRow newRow = CustomerOrders.NewRow();
                //newRow["CustomerOrderId"] = "CustomerOrderId";
                CustomerOrders.Rows.Add(newRow);

                adapter1.Update(CustomerOrders);
                
                // Indirectly get the CustomerOrderId by reading the dataset rows 
                // to get to the last record created by this customer.
                conn.Open();
                string query = @"SELECT CustomerOrderId FROM CustomerOrders WHERE CustId='"
                             + order.Customer.CustId.ToString() + "'";

                SqlCommand cmd = new SqlCommand(query, conn);
                FK_CustomerOrderId = "";
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    FK_CustomerOrderId = reader["CustomerOrderId"].ToString();
                }
                if (reader != null)
                {
                    reader.Close();
                }

                // Build SqlDataAdapter (adapter1) to update the OrderDetails table 
                // Create a SqlDataAdapter based on a SELECT query.
                adapter2 =
                    new SqlDataAdapter(
                    @"SELECT OrderId, ISBN, Title, Author, Price, Qty, CustomerOrderId FROM OrderDetails",
                    conn);

                // OrderDetails table gets one-to-many records inserted,
                // from the Order's ItemList, with the Customer's Order Id
                foreach (ItemDetails item in order.ItemList)
                {
                    string insertSQLstmt2 = @"INSERT INTO OrderDetails "
                                          + "(OrderId, ISBN, Title, Author, Price, Qty, CustomerOrderId) "
                                          + "VALUES "
                                          + "(NEWID(), "
                                          + "'" + item.Isbn + "', "
                                          + "'" + item.Title + "', "
                                          + "'" + item.Author + "', "
                                          + "'" + item.Price + "', "
                                          + "'" + item.Qty + "', "
                                          + "'" + FK_CustomerOrderId + "')";

                    //Create the SqlCommand to execute the Insert Sql statement.
                    adapter2.InsertCommand = new SqlCommand(insertSQLstmt2, conn);
                    adapter2.InsertCommand.CommandType = CommandType.Text;

                    // Add the parameter for the LastName. Specifying the
                    // ParameterDirection for an input parameter is not required.
                    adapter2.InsertCommand.Parameters.Add(
                        new SqlParameter("@OrderId", SqlDbType.UniqueIdentifier, 0, "OrderId"));

                    // Add the SqlParameter to retrieve the new identity value.
                    // Specify the ParameterDirection as Output.
                    parameter = adapter2.InsertCommand.Parameters.Add(
                        "@CustomerOrderId", SqlDbType.UniqueIdentifier, 0, "NEWID()");
                    parameter.Direction = ParameterDirection.Output;

                    // Create a DataTable and fill it.
                    System.Data.DataTable OrderDetails = new DataTable();
                    adapter2.Fill(OrderDetails);

                    // Add a new row. 
                    newRow = OrderDetails.NewRow();
                    //newRow["OrderId"] = "OrderId";
                    OrderDetails.Rows.Add(newRow);

                    adapter2.Update(OrderDetails);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (adapter != null)
                {
                    adapter.Dispose();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return FK_CustomerOrderId;
        }

        public static void AddCustomerData(ContactDetails customer)
        {
            SqlConnection conn = null;
            SqlDataAdapter adapter = null;
            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                //string connState;
                //   SqlDataReader reader = null;

                // Create a SqlDataAdapter based on a SELECT query.
                adapter = new SqlDataAdapter(@"SELECT CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, "
                                            + "CardType, CardNumber, CardExpire FROM Customer", conn);

                //For Production - Create the Insert Sql statement to add a customer record
                string insertSQLstmt = @"INSERT INTO Customer "
                                     + "(CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, "
                                     + "CardType, CardNumber, CardExpire) "
                                     + "VALUES "
                                     + "(NEWID(), "
                                     + "'" + customer.LastName + "', "
                                     + "'" + customer.FirstName + "', "
                                     + "'" + customer.Address + "', "
                                     + "'" + customer.City + "', "
                                     + "'" + customer.State + "', "
                                     + "'" + customer.ZipCode + "', "
                                     + "'" + customer.Phone + "', "
                                     + "'" + customer.Email + "', "
                                     + "'" + customer.CardType + "', "
                                     + "'" + customer.CardNumber + "', "
                                     + "'" + customer.CardExpire + "')";
                
                //Create the SqlCommand to execute the Insert Sql statement.
                adapter.InsertCommand = new SqlCommand(insertSQLstmt, conn);
                adapter.InsertCommand.CommandType = CommandType.Text;

                // Add the parameter for the LastName. Specifying the
                // ParameterDirection for an input parameter is not required.
                adapter.InsertCommand.Parameters.Add(
                    new SqlParameter("@LastName", SqlDbType.NVarChar, 15, "LastName"));

                // Add the SqlParameter to retrieve the new identity value.
                // Specify the ParameterDirection as Output.
                SqlParameter parameter =
                    adapter.InsertCommand.Parameters.Add(
                    "@CustId", SqlDbType.UniqueIdentifier, 0, "NEWID()");
                parameter.Direction = ParameterDirection.Output;

                // Create a DataTable and fill it.
                System.Data.DataTable Customer = new DataTable();
                adapter.Fill(Customer);

                // Add a new row. 
                DataRow newRow = Customer.NewRow();
                newRow["LastName"] = "New LastName";
                Customer.Rows.Add(newRow);

                adapter.Update(Customer);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (adapter != null)
                {
                    adapter.Dispose();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        public static void UpdateCustomerData(ContactDetails customer)
        {
            SqlConnection conn = null;
            SqlDataAdapter adapter = null;
            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                // Create a SqlDataAdapter based on a UPDATE query.
                adapter = new SqlDataAdapter(@"SELECT CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, "
                                            + "CardType, CardNumber, CardExpire FROM Customer", conn);

                //For Production - Create the UPDATE Sql statement to add a customer record
                string updateSQLstmt = @"UPDATE Customer SET "
                                     + "LastName  ='" + customer.LastName   + "', "
                                     + "FirstName ='" + customer.FirstName  + "', "
                                     + "Address   ='" + customer.Address    + "', "
                                     + "City      ='" + customer.City       + "', "
                                     + "State     ='" + customer.State      + "', "
                                     + "Zip       ='" + customer.ZipCode    + "', "
                                     + "Phone     ='" + customer.Phone      + "', "
                                     + "Email     ='" + customer.Email      + "', "
                                     + "CardType  ='" + customer.CardType   + "', "
                                     + "CardNumber='" + customer.CardNumber + "', "
                                     + "CardExpire='" + customer.CardExpire + "' "
                                     + "WHERE CustId = @CustId";

                //Create the SqlCommand to execute the Insert Sql statement.
                adapter.InsertCommand = new SqlCommand(updateSQLstmt, conn);
                adapter.InsertCommand.CommandType = CommandType.Text;

                // Add the parameter for the LastName. Specifying the
                // ParameterDirection for an input parameter is not required.
                adapter.InsertCommand.Parameters.Add(
                    new SqlParameter("@CustId", SqlDbType.NVarChar, 15, "CustId"));

                // Add the SqlParameter to retrieve the new identity value.
                // Specify the ParameterDirection as Output.
                SqlParameter parameter =
                    adapter.InsertCommand.Parameters.Add(
                    "@CustId", SqlDbType.UniqueIdentifier, 0, "NEWID()");
                parameter.Direction = ParameterDirection.Output;

                // Create a DataTable and fill it.
                System.Data.DataTable Customer = new DataTable();
                adapter.Fill(Customer);

                adapter.Update(Customer);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (adapter != null)
                {
                    adapter.Dispose();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        private static void RetrieveIdentity(SqlConnection connection)
        {
            // Create a SqlDataAdapter based on a SELECT query.
            SqlDataAdapter adapter =
                new SqlDataAdapter(
                "SELECT CustID, LastName FROM dbo.Customer",
                connection);

            //Create the SqlCommand to execute the stored procedure.
            adapter.InsertCommand = new SqlCommand("dbo.InsertCustomer",
                connection);
            adapter.InsertCommand.CommandType = CommandType.StoredProcedure;

            // Add the parameter for the LastName. Specifying the
            // ParameterDirection for an input parameter is not required.
            adapter.InsertCommand.Parameters.Add(
                new SqlParameter("@LastName", SqlDbType.NVarChar, 15,
                "LastName"));

            // Add the SqlParameter to retrieve the new identity value.
            // Specify the ParameterDirection as Output.
            SqlParameter parameter =
                adapter.InsertCommand.Parameters.Add(
                "@CustId", SqlDbType.Int, 0, "NEWID()");
            parameter.Direction = ParameterDirection.Output;

            // Create a DataTable and fill it.
            System.Data.DataTable Customer = new DataTable();
            adapter.Fill(Customer);

            // Add a new row. 
            DataRow newRow = Customer.NewRow();
            newRow["LastName"] = "New LastName";
            Customer.Rows.Add(newRow);

            adapter.Update(Customer);

            //Console.WriteLine("List All Rows:");
            foreach (DataRow row in Customer.Rows)
            {
                {
                    //Console.WriteLine("{0}: {1}", row[0], row[1]);
                    MessageBox.Show(row[1] + ":" + row[0]);
                }
            }
        }
    }
}
