﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.IO;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArkhamBooks
{
    public partial class OrderProcessing : frmOrderForm
    {

        /* A StringBuilder object appends to one string vs many literal strings;
         * the delimiter "|" is inserted to later parse the lines and items 
         * from the single string which represents one line for each order (record).

        // Instance variable for a StringBuilder
        private StringBuilder sb = new StringBuilder();

        // Utility method to create the order
        public static StringBuilder CreateOrder(StringBuilder sb)
        {
            // Add the customer data
            OrderDetails order = new OrderDetails();
            //BuildOrder(sb);

            return sb;
        }

        // Utility method to create the order
        public StringBuilder BuildOrder()
        {
            // Add the customer data
            OrderDetails order = new OrderDetails();
            RegisterCustomer(order);

            // Add the items the customer has put on the order (cart)
            ItemizeOrder(order);

            // Display the order details for confirmation and a receipt
            sb = DisplayOrder(order);

            // Write the order to the transaction data file
            // Called from the GUI Form instead of from here:
            //WriteOrderToFlatFile(sb);

            // Return the order to the calling Form
            return sb;
        }

        // Utility method to register the Customer in the Contact List
        protected void RegisterCustomer(OrderDetails order)
        {
            // Assign the (GUI) user-input to the properties of the Customer
            order.Customer.FirstName = txtFirstName.Text;
            order.Customer.LastName  = txtLastName.Text;
            order.Customer.Address   = txtAddress.Text;
            order.Customer.City      = txtCity.Text;
            order.Customer.State     = cboState.Text;
            order.Customer.ZipCode   = txtZipCode.Text;
            order.Customer.Email     = txtEmail.Text;

            // Add the Customer to the List of contacts
            List<ContactDetails> contactList = new List<ContactDetails>();
            contactList.Add(order.Customer);
            contactList.Sort();
        }

        // Utility method to Itemize the order for the customer
        protected void ItemizeOrder(OrderDetails order)
        {
            decimal subtotal;

            foreach (ItemDetails item in order.ItemList)
            {
                subtotal = item.Price * item.Qty;
                order.Subtotal += subtotal;
            }
        }

        // Utility method to display the order to the customer
        protected StringBuilder DisplayOrder(OrderDetails order)
        {
            // 
            // Specified in the Student Handbook on page 20.
            //
            // StringBuilder appends to one string vs many literal strings;
            // delimiter "|" is inserted to parse the lines and items later,
            // from the single line of each order.
            //
            // Start the string with the order date and the customer data
            sb.AppendFormat("Order Date: {0}|{1} {2}|{3}|{4}, {5} {6}|{7}|", 
                            order.OrderDate,
                            order.Customer.FirstName, order.Customer.LastName,
                            order.Customer.Address,
                            order.Customer.City, order.Customer.State, order.Customer.ZipCode,
                            order.Customer.Email);

            // Append the list of books ordered
            sb.AppendFormat("{0,-24}\t{1,-5}   {2}  ({3}) {4:-c2,15}|",
                            "Title", "Author", "ISBN", "Quantity", "Price");

            foreach (ItemDetails item in order.ItemList)
            {
                sb.AppendFormat("{0,-24}\t{1,-5}   {2}  ({3}) {4:-c2,15}|",
                            item.Title, item.Author, item.Isbn, item.Qty, item.Price);
            }

            // Append the summary line
            sb.AppendFormat("SubTotal: {0}   Tax: {1}   Shipping: {2}   Total {3} |",
                             order.Subtotal, order.Taxes, order.Shipping, order.Total);

            // Append the final line to separate orders
            sb.AppendFormat("-----------------------------------------------------------------\n");

            return sb;
        }

        // Utility method to write the order
        public static void WriteOrderToFlatFile(StringBuilder sb)
        {
            // Pg528. Writing to a sequential access text file
            // declare a delimiter, an output text file, and some arrays
            const string FILENAME = "OrderData.txt";
            
            if (File.Exists(FILENAME))
            {
                try
                {
                    // Use the File.WriteLine method to write the StringBuilder line. 
                    //  It creates a FileStream object, associates it with a StreamWriter
                    //  and later, closes the file. 

                    // Write to order file
                    File.WriteAllText(FILENAME, sb.ToString());

                }
                catch (Exception)
                {
                    //  throws NotEmplemented
                }
                finally 
                {
                    //  the File.WriteAllLines method also, closed the file.
                }
            }
        }
         */
    }
}
