-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:57 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_orderdetail`
--

CREATE TABLE IF NOT EXISTS `ab_orderdetail` (
  `OrderId` int(11) NOT NULL,
  `Isbn` varchar(13) NOT NULL,
  `Qty` int(11) default NULL,
  `Price` decimal(6,2) default NULL,
  PRIMARY KEY  (`OrderId`,`Isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ab_orderdetail`
--

INSERT INTO `ab_orderdetail` (`OrderId`, `Isbn`, `Qty`, `Price`) VALUES
(1, '0870541781', 1, 32.50),
(1, '0870541811', 1, 32.50),
(2, '0449242463', 1, 6.75),
(3, '0380820765', 1, 5.39),
(3, '0425198138', 2, 15.26),
(4, '0140296301', 1, 5.95),
(5, '0345470389', 1, 5.56),
(6, '0345345991', 3, 7.13),
(6, '0345453751', 1, 23.70),
(7, '0688010377', 1, 7.95),
(8, '0670032786', 2, 5.95),
(8, '0812574990', 1, 7.50),
(9, '0131103628', 1, 35.96),
(9, '0619016620', 1, 23.40),
(10, '1878252402', 1, 32.78),
(11, '0785269606', 1, 19.96),
(12, '0449214222', 1, 14.95),
(12, '0688010377', 2, 7.95);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
