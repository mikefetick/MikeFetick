-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:58 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_orders`
--

CREATE TABLE IF NOT EXISTS `ab_orders` (
  `OrderId` int(11) NOT NULL auto_increment,
  `OrderDate` datetime default NULL,
  `CustId` int(11) default NULL,
  `CardType` varchar(16) default NULL,
  `CardNumber` varchar(16) default NULL,
  `CardExpire` varchar(5) default NULL,
  PRIMARY KEY  (`OrderId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `ab_orders`
--

INSERT INTO `ab_orders` (`OrderId`, `OrderDate`, `CustId`, `CardType`, `CardNumber`, `CardExpire`) VALUES
(1, '2003-09-10 00:00:00', 1, 'Visa', '4224369869563521', '07/07'),
(2, '2003-10-10 00:00:00', 2, 'American Express', '370044875669745', '06/05'),
(3, '2003-12-17 00:00:00', 2, 'American Express', '370044875669745', '06/05'),
(4, '2004-01-12 00:00:00', 1, 'Visa', '4224369869563521', '07/07'),
(5, '2004-01-24 00:00:00', 4, 'Discover', '6987326528742587', '02/06'),
(6, '2004-02-29 00:00:00', 5, 'Master Card', '5365879658752414', '03/08'),
(7, '2004-03-02 00:00:00', 6, 'Master Card', '5224369865214785', '01/06'),
(8, '2004-03-10 00:00:00', 6, 'Master Card', '5224369865214785', '01/06'),
(9, '2004-04-23 00:00:00', 2, 'American Express', '370044875669745', '06/05'),
(10, '2004-05-14 00:00:00', 5, 'Master Card', '5365879658752414', '03/08'),
(11, '2004-05-14 00:00:00', 4, 'Discover', '6987326528742587', '02/06'),
(12, '2004-05-20 00:00:00', 1, 'Visa', '4224369869563521', '07/07');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
