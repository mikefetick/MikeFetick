-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:57 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_customer`
--

CREATE TABLE IF NOT EXISTS `ab_customer` (
  `CustId` int(11) NOT NULL auto_increment,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(15) NOT NULL,
  `Address` varchar(30) default NULL,
  `City` varchar(20) default NULL,
  `State` char(2) default NULL,
  `Zip` varchar(10) default NULL,
  `Phone` char(12) default NULL,
  `Email` varchar(35) default NULL,
  `CardType` varchar(16) default NULL,
  `CardNumber` varchar(16) default NULL,
  `CardExpire` varchar(5) default NULL,
  PRIMARY KEY  (`CustId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `ab_customer`
--

INSERT INTO `ab_customer` (`CustId`, `LastName`, `FirstName`, `Address`, `City`, `State`, `Zip`, `Phone`, `Email`, `CardType`, `CardNumber`, `CardExpire`) VALUES
(1, 'Richardson', 'John', '1524 Center Dr.', 'La Mesa', 'CA', '91945', '619-358-6578', 'jrich@cox.net', 'Visa', '4224369865742591', '03/07'),
(2, 'Lolan', 'Bobbi', '122 Elysian Fields', 'New Orleans', 'LA', '73401', '704-987-6421', 'blolan@no.rr.net', 'Master Card', '5623326598754128', '02/05'),
(3, 'Smith', 'Tim', '12597 1st Ave.', 'Chula Vista', 'CA', '92174', '619-658-8794', 'tsmith@sbcglobal.net', 'Discover', '6598234568710954', '04/06'),
(4, 'Edwards', 'Mitch', '19872 Pine Court', 'Kansas City', 'MO', '69877', '648-987-0938', 'mitch@earthnet.com', 'American Express', '370044875669745', '10/04'),
(5, 'Brown', 'Edward', '14598 Poway Road', 'Poway', 'CA', '92064', '858-486-6897', 'ebrown@hobo.net', 'Master Card', '5236698756824712', '09/05'),
(6, 'Rowland', 'Mike', '32657 Jasmine Place', 'Park City', 'UT', '86987', '236-568-9874', 'roland@hotmail.com', 'Visa', '4225639856875214', '12/04'),
(7, 'Perkins', 'Anthony', '235 Circle Dr.', 'La Mesa', 'CA', '91942', '247-986-3274', 'psycho@bates.com', 'Master Card', '5668213659875897', '12/05'),
(8, 'Jones', 'Ralph', '2 Shady Lane', 'Chula Vista', 'CA', '92105', '254-987-2327', 'shady@nightmare.com', 'Discover', '6987986215476387', '01/07');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
