﻿using System;

public class Class1
{
    // public List<Employee> find (Employee e);  // Not effective because we don't have all the data, just the search string
    // public List<Employee> find (string, int, params);   // Potential problem - the array doesn't know which param was passed
    // ... We can overload the find method 6 different ways to Sunday - unsuccessful.
    // We should use a Dictionary...
    // public List<Employee> find (Dictionary d);  
 
    public class Employee();

	public DBUtilities
	{
        public int InsertEmployee(Employee e);
        public Boolean DeleteEmployee(int employeeId);
        public Boolean UpdateEmployee(Employee e);
        public Employee FindEmployee(Employee e);
	}
}  // WHERE LastName LIKE '%' + @LastName + '%';
// Regular Expressions - Regex Class 
// In TSQL use PATINDEX function
// Regex re = Regex();

// SQL Parameter - Copying data to any parameter values in the stack frame - special kind of variable
// they start beyond the scope, before the method body; but they don't last beyond the scope.
// The parameter is also a class, there are Parametere Data Types  - there is a bridge between but thier not the same 
/*
 * Difference between Parameterized Query and a Stored Procedure:
 * Parameterized Query on a Database  - * Written procedures that query with Placeholders - We do it once!
 * * 1- Parswe Syntax
 * * 2- MArshall Execution Plan
 * 3- Execute - do this many times!
 * 
 * Stored Procedure - x Stored on the database once, and never looked at again. Downside - Learn yet another syntax.
 * x 1- Parswe Syntax
 * x 2- MArshall Execution Plan
 * 3- Execute - do this many times!
 * 
 */
